
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { UserProfile, Match, Transaction, UserTeam, AuthSession, JoinedContest, Contest } from './types';
import { MOCK_MATCHES, MOCK_CONTESTS } from './data/mockData';
import Navbar from './components/Navbar';
import MatchList from './components/MatchList';
import MatchDetails from './components/MatchDetails';
import TeamBuilder from './components/TeamBuilder';
import Wallet from './components/Wallet';
import Leaderboard from './components/Leaderboard';
import Auth from './components/Auth';
import KYC from './components/KYC';
import Referral from './components/Referral';
import HelpSupport from './components/HelpSupport';
import Walkthrough from './components/Walkthrough';
import ResponsiblePlay from './components/ResponsiblePlay';
import AnnouncementBanner from './components/AnnouncementBanner';
import AdminKYC from './components/AdminKYC';
import AdminContestManager from './components/AdminContestManager';
import { WalletService } from './services/wallet.service';
import { ContestService } from './services/contest.service';
import { SportsDataService } from './services/sports.service';

const NavigationWrapper: React.FC<{ user: UserProfile | null; onLogout: () => void; children: React.ReactNode }> = ({ user, onLogout, children }) => {
  const location = useLocation();
  const isTeamBuilder = location.pathname.includes('/create-team');

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <AnnouncementBanner announcement={{ id: '1', type: 'INFO', message: 'T20 World Cup Final Live! Score correction window is 30 mins post-match.' }} />
      {user && <Navbar user={user} onLogout={onLogout} />}
      <main className={`flex-grow container mx-auto px-4 py-6 max-w-2xl ${user && !isTeamBuilder ? 'pb-24' : ''}`}>
        {children}
      </main>
      {user && !isTeamBuilder && (
        <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center py-2 z-50 md:hidden h-20 shadow-[0_-4px_20px_rgba(0,0,0,0.08)] px-1">
          <Link to="/" className={`flex flex-col items-center ${location.pathname === '/' ? 'text-red-600' : 'text-gray-400'}`}>
            <i className="fas fa-home text-lg"></i>
            <span className="text-[8px] font-black mt-1 uppercase tracking-tighter">Home</span>
          </Link>
          <Link to="/leaderboard" className={`flex flex-col items-center ${location.pathname === '/leaderboard' ? 'text-red-600' : 'text-gray-400'}`}>
            <i className="fas fa-trophy text-lg"></i>
            <span className="text-[8px] font-black mt-1 uppercase tracking-tighter">Winner</span>
          </Link>
          <Link to="/wallet" className={`flex flex-col items-center ${location.pathname === '/wallet' ? 'text-red-600' : 'text-gray-400'}`}>
            <i className="fas fa-wallet text-lg"></i>
            <span className="text-[8px] font-black mt-1 uppercase tracking-tighter">Wallet</span>
          </Link>
          <Link to="/kyc" className={`flex flex-col items-center ${location.pathname === '/kyc' ? 'text-red-600' : 'text-gray-400'}`}>
            <i className="fas fa-id-card text-lg"></i>
            <span className="text-[8px] font-black mt-1 uppercase tracking-tighter">KYC</span>
          </Link>
          {user.role === 'ADMIN' && (
            <Link to="/admin/settlements" className={`flex flex-col items-center ${location.pathname === '/admin/settlements' ? 'text-red-600' : 'text-gray-400'}`}>
              <i className="fas fa-money-bill-trend-up text-lg"></i>
              <span className="text-[8px] font-black mt-1 uppercase tracking-tighter">Settle</span>
            </Link>
          )}
        </nav>
      )}
    </div>
  );
};

const App: React.FC = () => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [userTeams, setUserTeams] = useState<UserTeam[]>([]);
  const [joinedContests, setJoinedContests] = useState<JoinedContest[]>([]);
  const [showWalkthrough, setShowWalkthrough] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [matches, setMatches] = useState<Match[]>(MOCK_MATCHES);
  const [dynamicContests, setDynamicContests] = useState<Contest[]>(MOCK_CONTESTS);

  useEffect(() => {
    const initApp = async () => {
      // 1. Load Local Storage
      const savedSession = localStorage.getItem('pro_session');
      const savedTeams = localStorage.getItem('fantasy_teams');
      const savedJoined = localStorage.getItem('fantasy_joined');
      
      if (savedSession) {
        const parsedSession: AuthSession = JSON.parse(savedSession);
        if (parsedSession.expiresAt > Date.now()) {
          const u = parsedSession.user;
          if (u.selfExclusionUntil && new Date(u.selfExclusionUntil) > new Date()) {
             alert("Your account is frozen for Responsible Play until " + new Date(u.selfExclusionUntil).toLocaleString());
             handleLogout();
          } else {
             setUser(u);
             if (u.isNewUser) setShowWalkthrough(true);
          }
        }
      }
      if (savedTeams) setUserTeams(JSON.parse(savedTeams));
      if (savedJoined) setJoinedContests(JSON.parse(savedJoined));

      // 2. Fetch Live Matches
      try {
        const liveMatches = await SportsDataService.getRealtimeFixtures();
        if (liveMatches && liveMatches.length > 0) {
          // Merge logic: prefer live matches, fallback to mock if list is empty
          setMatches(liveMatches);
          
          // Ensure mock contests are mapped to some real match IDs for demo visibility if needed
          // For now we just use the matches from AI
        }
      } catch (err) {
        console.error("Failed to fetch live matches:", err);
        setMatches(MOCK_MATCHES);
      } finally {
        setIsLoading(false);
      }
    };

    initApp();
  }, []);

  const handleLogin = (newSession: AuthSession) => {
    setUser(newSession.user);
    if (newSession.user.isNewUser) setShowWalkthrough(true);
    localStorage.setItem('pro_session', JSON.stringify(newSession));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('pro_session');
  };

  const handleSaveTeam = (t: UserTeam) => {
    const updated = [...userTeams, t];
    setUserTeams(updated);
    localStorage.setItem('fantasy_teams', JSON.stringify(updated));
  };

  const handleAdminUpdate = (data: { updatedUsers: UserProfile[], transactions: Transaction[], updatedContest: Contest }) => {
    const foundUser = data.updatedUsers.find(u => u.id === user?.id);
    if (foundUser) {
      setUser(foundUser);
      localStorage.setItem('pro_session', JSON.stringify({ ...JSON.parse(localStorage.getItem('pro_session')!), user: foundUser }));
    }
    setDynamicContests(prev => prev.map(c => c.id === data.updatedContest.id ? data.updatedContest : c));
  };

  if (isLoading) return (
    <div className="min-h-screen bg-gray-950 flex flex-col items-center justify-center">
      <div className="w-12 h-12 border-4 border-red-600 border-t-transparent rounded-full animate-spin mb-4"></div>
      <p className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Synchronizing Stadium Data...</p>
    </div>
  );

  return (
    <Router>
      {showWalkthrough && <Walkthrough onComplete={() => setShowWalkthrough(false)} />}
      <NavigationWrapper user={user} onLogout={handleLogout}>
        <Routes>
          {!user ? (
            <Route path="*" element={<Auth onLogin={handleLogin} />} />
          ) : (
            <>
              <Route path="/" element={<MatchList matches={matches} />} />
              <Route path="/match/:matchId" element={
                <MatchDetails 
                  matches={matches} user={user} 
                  userTeams={userTeams} joinedContests={joinedContests} 
                  onJoin={async (c, t) => {
                    const res = await ContestService.joinContest(user, c, t);
                    if (res.success) {
                      setUser(res.updatedUser!);
                      setJoinedContests([...joinedContests, res.joinedContest!]);
                      return true;
                    }
                    return false;
                  }}
                  onClone={() => {}}
                />
              } />
              <Route path="/match/:matchId/create-team" element={<TeamBuilder onSave={handleSaveTeam} user={user} />} />
              <Route path="/wallet" element={<Wallet user={user} transactions={[]} onUpdate={() => {}} />} />
              <Route path="/leaderboard" element={<Leaderboard userTeams={userTeams} joinedContests={joinedContests} />} />
              <Route path="/kyc" element={<KYC user={user} onUpdate={setUser} />} />
              <Route path="/safety" element={<ResponsiblePlay user={user} onUpdate={setUser} />} />
              <Route path="/referral" element={<Referral user={user} />} />
              <Route path="/help" element={<HelpSupport />} />
              {user.role === 'ADMIN' && (
                <>
                  <Route path="/admin/kyc" element={<AdminKYC user={user} />} />
                  <Route path="/admin/settlements" element={
                    <AdminContestManager 
                      contests={dynamicContests} 
                      matches={matches} 
                      allUsers={[user]} 
                      userTeams={userTeams} 
                      joinedContests={joinedContests}
                      onUpdate={handleAdminUpdate}
                    />
                  } />
                </>
              )}
              <Route path="*" element={<Navigate to="/" />} />
            </>
          )}
        </Routes>
      </NavigationWrapper>
    </Router>
  );
};

export default App;
