
import { UserTeam, Player } from '../types';

export interface LeaderboardEntry {
  rank: number;
  userName: string;
  points: number;
  teamId: string;
  isUser: boolean;
  avatar: string;
  movement: 'UP' | 'DOWN' | 'NONE';
  isTie?: boolean;
}

export class LeaderboardService {
  static calculateTeamPoints(team: UserTeam, livePlayers: Player[]): number {
    let total = 0;
    team.playerIds.forEach(pid => {
      // Find matching player, stripping any match-specific prefixes if needed
      const player = livePlayers.find(p => p.id === pid || p.id.split('_').pop() === pid.split('_').pop());
      if (player) {
        let pts = player.points || 0;
        if (pid === team.captainId) pts *= 2;
        else if (pid === team.viceCaptainId) pts *= 1.5;
        total += pts;
      }
    });
    return total;
  }

  static generateLiveRankings(userTeams: UserTeam[], livePlayers: Player[]): LeaderboardEntry[] {
    const rawEntries: Omit<LeaderboardEntry, 'rank'>[] = [];

    userTeams.forEach(ut => {
      const pts = this.calculateTeamPoints(ut, livePlayers);
      rawEntries.push({
        userName: "You",
        points: pts,
        teamId: ut.id,
        isUser: true,
        avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=User",
        movement: 'NONE'
      });
    });

    // Add Simulated Competition
    for (let i = 0; i < 20; i++) {
      rawEntries.push({
        userName: `User_${i + 100}`,
        points: Math.floor(Math.random() * 200),
        teamId: `sim_${i}`,
        isUser: false,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=Sim${i}`,
        movement: 'NONE'
      });
    }

    rawEntries.sort((a, b) => b.points - a.points);

    const finalEntries: LeaderboardEntry[] = [];
    let rankToAssign = 1;

    for (let i = 0; i < rawEntries.length; i++) {
      if (i > 0 && rawEntries[i].points < rawEntries[i - 1].points) {
        rankToAssign = i + 1;
      }
      finalEntries.push({ ...rawEntries[i], rank: rankToAssign });
    }

    return finalEntries;
  }
}
