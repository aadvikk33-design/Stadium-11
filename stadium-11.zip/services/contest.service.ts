
import { Contest, UserProfile, UserTeam, JoinedContest } from '../types';
import { WalletService } from './wallet.service';

/**
 * CONTEST LOCKING SERVICE
 * Simulates high-concurrency locking and atomic spot updates.
 */
export class ContestService {
  private static mockFilledSpots: Map<string, number> = new Map();

  static getLiveSpots(contest: Contest): number {
    return this.mockFilledSpots.get(contest.id) || contest.filledSpots;
  }

  /**
   * M-016: Atomically join a contest
   */
  static async joinContest(
    user: UserProfile, 
    contest: Contest, 
    team: UserTeam
  ): Promise<{ 
    success: boolean; 
    updatedUser?: UserProfile; 
    joinedContest?: JoinedContest; 
    message: string 
  }> {
    // 1. Concurrency Check (Simulated Lock)
    const currentSpots = this.getLiveSpots(contest);
    if (currentSpots >= contest.totalSpots) {
      return { success: false, message: "Contest is full! Try another one." };
    }

    // 2. Eligibility Checks
    if (user.walletBalance < contest.entryFee) {
      return { success: false, message: "Insufficient balance. Please add cash." };
    }

    // 3. Process Transaction (Double-entry check)
    try {
      const { updatedUser } = WalletService.processEntryFee(user, contest.entryFee);
      
      // 4. Update Spot Count (Atomic Simulation)
      this.mockFilledSpots.set(contest.id, currentSpots + 1);

      const joined: JoinedContest = {
        id: `jc_${Math.random().toString(36).substr(2, 9)}`,
        contestId: contest.id,
        matchId: contest.matchId,
        teamId: team.id,
        joinedAt: new Date().toISOString()
      };

      return {
        success: true,
        updatedUser: {
          ...updatedUser,
          contestsJoined: (user.contestsJoined || 0) + 1
        },
        joinedContest: joined,
        message: "Successfully joined contest!"
      };
    } catch (error: any) {
      return { success: false, message: error.message || "Transaction failed." };
    }
  }

  /**
   * Simulates high traffic by filling spots periodically
   */
  static simulateTraffic(contests: Contest[]) {
    contests.forEach(c => {
      const current = this.getLiveSpots(c);
      if (current < c.totalSpots) {
        // Randomly add 1-5 spots every few seconds
        const gain = Math.floor(Math.random() * 5);
        this.mockFilledSpots.set(c.id, Math.min(c.totalSpots, current + gain));
      }
    });
  }
}
