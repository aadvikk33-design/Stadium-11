
import { Contest, PrizeStructure, PrizeSlab } from '../types';

export const MOCK_PRIZE_STRUCTURES: PrizeStructure[] = [
  {
    id: 'ps_winner_takes_all',
    name: 'Winner Takes All',
    slabs: [{ rankStart: 1, rankEnd: 1, percentage: 100 }]
  },
  {
    id: 'ps_top_3',
    name: 'Top 3 Distribution',
    slabs: [
      { rankStart: 1, rankEnd: 1, percentage: 50 },
      { rankStart: 2, rankEnd: 2, percentage: 30 },
      { rankStart: 3, rankEnd: 3, percentage: 20 },
    ]
  },
  {
    id: 'ps_mega',
    name: 'Mega 50% Winners',
    slabs: [
      { rankStart: 1, rankEnd: 1, percentage: 10 },
      { rankStart: 2, rankEnd: 10, percentage: 15 },
      { rankStart: 11, rankEnd: 100, percentage: 25 },
      { rankStart: 101, rankEnd: 1000, percentage: 50 },
    ]
  }
];

export class PrizeEngine {
  /**
   * Calculates the platform rake amount.
   */
  static getPlatformRake(contest: Contest): number {
    const grossCollection = this.getGrossCollection(contest);
    return (grossCollection * contest.rakePercentage) / 100;
  }

  /**
   * Calculates gross collection based on filled spots.
   */
  static getGrossCollection(contest: Contest): number {
    return contest.filledSpots * contest.entryFee;
  }

  /**
   * Calculates the net prize pool available for distribution.
   */
  static getNetPrizePool(contest: Contest): number {
    if (contest.isGuaranteed) {
      // For guaranteed contests, the pool is fixed based on total spots
      const totalCapacityPool = contest.totalSpots * contest.entryFee;
      const rakeOnTotal = (totalCapacityPool * contest.rakePercentage) / 100;
      return totalCapacityPool - rakeOnTotal;
    } else {
      // For non-guaranteed, it scales with filled spots
      const gross = this.getGrossCollection(contest);
      const rake = (gross * contest.rakePercentage) / 100;
      return gross - rake;
    }
  }

  /**
   * Gets the prize amount for a specific rank range.
   */
  static getPrizeForRank(contest: Contest, rank: number): number {
    const netPool = this.getNetPrizePool(contest);
    const structure = MOCK_PRIZE_STRUCTURES.find(ps => ps.id === contest.prizeStructureId);
    if (!structure) return 0;

    const slab = structure.slabs.find(s => rank >= s.rankStart && rank <= s.rankEnd);
    if (!slab) return 0;

    const ranksInSlab = (slab.rankEnd - slab.rankStart) + 1;
    const slabTotalPrize = (netPool * slab.percentage) / 100;
    
    return Math.floor(slabTotalPrize / ranksInSlab);
  }

  /**
   * Standard Tie Handling:
   * When multiple users share a rank, we combine the prizes of all ranks they would have occupied
   * and split the total equally.
   */
  static calculateTiePrizes(contest: Contest, startingRank: number, tieCount: number): number {
    let totalPrize = 0;
    for (let i = 0; i < tieCount; i++) {
      totalPrize += this.getPrizeForRank(contest, startingRank + i);
    }
    return Math.floor(totalPrize / tieCount);
  }

  static getPrizeTable(contest: Contest): { rank: string, amount: number }[] {
    const structure = MOCK_PRIZE_STRUCTURES.find(ps => ps.id === contest.prizeStructureId);
    if (!structure) return [];

    return structure.slabs.map(slab => ({
      rank: slab.rankStart === slab.rankEnd ? `#${slab.rankStart}` : `#${slab.rankStart} - ${slab.rankEnd}`,
      amount: this.getPrizeForRank(contest, slab.rankStart)
    }));
  }
}
