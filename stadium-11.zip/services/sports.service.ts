
import { GoogleGenAI, Type } from "@google/genai";
import { Match, Player, PlayerRole, PlayerLifecycle } from "../types";

export class SportsDataService {
  private static ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  static async getRealtimeFixtures(): Promise<Match[]> {
    try {
      const now = new Date();
      const istDate = now.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
      
      const prompt = `Role: Real-time Sports Data Engineer.
      Fetch actual live and upcoming cricket matches for ${istDate}.
      Return as a JSON array of matches with fields: id, team1, team1Logo, team2, team2Logo, startTime (ISO), status, series, venue, score.`;

      const response = await this.ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                team1: { type: Type.STRING },
                team1Logo: { type: Type.STRING },
                team2: { type: Type.STRING },
                team2Logo: { type: Type.STRING },
                startTime: { type: Type.STRING },
                status: { type: Type.STRING, enum: ['LIVE', 'UPCOMING', 'COMPLETED'] },
                series: { type: Type.STRING },
                venue: { type: Type.STRING },
                score: { type: Type.STRING }
              }
            }
          }
        }
      });

      const rawMatches = JSON.parse(response.text);
      
      // Ensure all required fields for the Match interface are present
      return rawMatches.map((m: any) => ({
        ...m,
        tossReleased: m.status === 'LIVE' || m.status === 'COMPLETED',
        lockConfig: {
          teamEditSeconds: 60, // Default: Lock 1 minute before start
          contestJoinSeconds: 0,
          captainSwapSeconds: 0
        }
      }));
    } catch (error) {
      console.error("[SportsDataService] Fetch Error:", error);
      return [];
    }
  }

  static async getSquadForMatch(match: Match): Promise<Player[]> {
    try {
      const prompt = `Fetch the full squads (approximately 22-30 players) for the match: ${match.team1} vs ${match.team2}.
      Return JSON array with fields: name, team, role (WK, BAT, AR, BOWL), credits (8.0 to 11.0), isPlayingXI (boolean), selectedBy (percentage).`;

      const response = await this.ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                team: { type: Type.STRING },
                role: { type: Type.STRING, enum: ['WK', 'BAT', 'AR', 'BOWL'] },
                credits: { type: Type.NUMBER },
                isPlayingXI: { type: Type.BOOLEAN },
                selectedBy: { type: Type.NUMBER }
              }
            }
          }
        }
      });

      const rawPlayers = JSON.parse(response.text);
      return rawPlayers.map((p: any, i: number) => ({
        id: `p_${match.id}_${i}`,
        name: p.name,
        team: p.team,
        role: p.role as PlayerRole,
        credits: p.credits || 9.0,
        points: 0,
        imageUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${p.name}`,
        lifecycle: PlayerLifecycle.CONFIRMED,
        isPlayingXI: p.isPlayingXI ?? false,
        selectedBy: p.selectedBy ?? Math.floor(Math.random() * 80)
      }));
    } catch (error) {
      console.error("[SportsDataService] Squad Fetch Error:", error);
      return [];
    }
  }
}
