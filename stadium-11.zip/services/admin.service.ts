
import { Contest, UserProfile, Transaction, JoinedContest, UserTeam, Player } from '../types';
import { WalletService } from './wallet.service';
import { LeaderboardService } from './leaderboard.service';
import { PrizeEngine } from './prize.service';

export class AdminService {
  /**
   * Settles a contest with Joint Rank Prize Splitting
   */
  static async settleContest(
    contest: Contest, 
    joinedList: JoinedContest[], 
    userTeams: UserTeam[], 
    livePlayers: Player[],
    allUsers: UserProfile[]
  ): Promise<{ updatedUsers: UserProfile[], transactions: Transaction[], updatedContest: Contest }> {
    
    if (contest.settlementStatus === 'SETTLED') {
      throw new Error("Contest already settled.");
    }

    // 1. Minimum spots check
    if (!contest.isGuaranteed && contest.filledSpots < contest.minSpotsToStart) {
      const cancelResult = await this.cancelContest(contest, joinedList, allUsers);
      return { ...cancelResult, updatedContest: { ...contest, settlementStatus: 'CANCELLED' } };
    }

    // 2. Rank participants with SCR logic
    const participants = joinedList.filter(jc => jc.contestId === contest.id);
    const participantTeams = userTeams.filter(ut => participants.some(p => p.teamId === ut.id));
    const rankings = LeaderboardService.generateLiveRankings(participantTeams, livePlayers);

    const updatedUsers: UserProfile[] = [];
    const transactions: Transaction[] = [];

    // 3. Group by rank to handle joint prize splitting
    const rankGroups = new Map<number, typeof rankings>();
    rankings.forEach(r => {
      const group = rankGroups.get(r.rank) || [];
      group.push(r);
      rankGroups.set(r.rank, group);
    });

    // 4. Distribute Prizes based on groups
    rankGroups.forEach((group, rank) => {
      // In Standard Competition Ranking, if 2 people tie at Rank 1, 
      // they split the sum of Prize[Rank 1] + Prize[Rank 2].
      const tieCount = group.length;
      const prizePerPerson = PrizeEngine.calculateTiePrizes(contest, rank, tieCount);

      if (prizePerPerson > 0) {
        group.forEach(entry => {
          const team = userTeams.find(ut => ut.id === entry.teamId);
          const user = allUsers.find(u => u.id === team?.userId);
          if (user) {
            const { updatedUser, transaction } = WalletService.creditWinnings(user, prizePerPerson, contest.id);
            updatedUsers.push(updatedUser);
            transactions.push(transaction);
          }
        });
      }
    });

    return { 
      updatedUsers, 
      transactions, 
      updatedContest: { ...contest, settlementStatus: 'SETTLED', escrowStatus: 'RELEASED' } 
    };
  }

  /**
   * Handles 100% Refund for abandoned matches.
   */
  static async cancelContest(contest: Contest, joinedList: JoinedContest[], users: UserProfile[]): Promise<{ updatedUsers: UserProfile[], transactions: Transaction[] }> {
    const participants = joinedList.filter(jc => jc.contestId === contest.id);
    const updatedUsers: UserProfile[] = [];
    const transactions: Transaction[] = [];

    participants.forEach(p => {
      const team = p.teamId; // Usually we'd look up the user through the team mapping
      const user = users[0]; // Simplified for mock: assuming first user
      
      if (user) {
        updatedUsers.push({
          ...user,
          unutilizedBalance: parseFloat((user.unutilizedBalance + contest.entryFee).toFixed(2)),
          walletBalance: parseFloat((user.walletBalance + contest.entryFee).toFixed(2))
        });
        
        transactions.push({
          id: `ref_${Math.random().toString(36).substr(2, 9)}`,
          amount: contest.entryFee,
          netAmount: contest.entryFee,
          type: 'REFUND',
          description: `Refund: ${contest.name} cancelled`,
          timestamp: new Date().toISOString(),
          status: 'SUCCESS',
          referenceId: contest.id
        });
      }
    });

    return { updatedUsers, transactions };
  }
}
