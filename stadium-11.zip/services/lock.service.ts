
import { Match, MatchLockStatus } from '../types';

export class LockService {
  static getLockStatus(match: Match): MatchLockStatus {
    const now = Date.now();
    const startTime = new Date(match.startTime).getTime();
    const diffSeconds = (startTime - now) / 1000;

    const canJoin = diffSeconds > match.lockConfig.contestJoinSeconds;
    const canEdit = diffSeconds > match.lockConfig.teamEditSeconds;
    const canChangeCaptain = diffSeconds > match.lockConfig.captainSwapSeconds;

    let message;
    if (!canJoin) message = "Contest joining is locked.";
    if (!canEdit) message = "Team editing is locked.";
    if (match.status !== 'UPCOMING') message = "Match has started.";

    return {
      canJoinContest: canJoin && match.status === 'UPCOMING',
      canEditTeam: canEdit && match.status === 'UPCOMING',
      canChangeCaptain: canChangeCaptain && match.status === 'UPCOMING',
      lockMessage: message
    };
  }
}
