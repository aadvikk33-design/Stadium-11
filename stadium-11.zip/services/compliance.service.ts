
export class ComplianceService {
  // States where real money gaming is restricted in India
  private static RESTRICTED_STATES = [
    'Assam', 'Odisha', 'Telangana', 'Andhra Pradesh', 'Sikkim', 'Nagaland'
  ];

  static isStateAllowed(state: string): boolean {
    return !this.RESTRICTED_STATES.includes(state);
  }

  static validatePAN(pan: string): boolean {
    const regex = /[A-Z]{5}[0-9]{4}[A-Z]{1}/;
    return regex.test(pan.toUpperCase());
  }

  static calculateAge(dob: string): number {
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }

  static isAgeEligible(dob: string): boolean {
    return this.calculateAge(dob) >= 18;
  }

  static getRestrictedStates() {
    return this.RESTRICTED_STATES;
  }
}
