
import { UserProfile, AuthSession, OTPChallenge, DeviceMetadata } from '../types';
import { Security } from '../lib/security';

// Simulated DB for uniqueness check and persistence
const MOCK_DB_KEY = 'fantasy_pro_users_db';

export class AuthService {
  private static activeOTP: Map<string, OTPChallenge> = new Map();

  private static getUsersFromDB(): any[] {
    const data = localStorage.getItem(MOCK_DB_KEY);
    return data ? JSON.parse(data) : [];
  }

  private static saveUserToDB(user: any) {
    const users = this.getUsersFromDB();
    const existingIdx = users.findIndex(u => u.email === user.email);
    if (existingIdx >= 0) {
      users[existingIdx] = user;
    } else {
      users.push(user);
    }
    localStorage.setItem(MOCK_DB_KEY, JSON.stringify(users));
  }

  private static hashPassword(password: string): string {
    // Simple mock hash for demo: Reversal + salt
    return "SALT_" + password.split("").reverse().join("");
  }

  static async emailSignup(email: string, password: string, dob: string, username: string): Promise<{ success: boolean; message: string; session?: AuthSession }> {
    const users = this.getUsersFromDB();
    if (users.find(u => u.email === email)) {
      return { success: false, message: "Email already registered. Please login." };
    }

    const newUser = this.createUserProfile(email, 'EMAIL');
    newUser.username = username || email.split('@')[0];
    newUser.dob = dob;

    // In a real app, the DB would store the hashed password.
    // For this mock, we store the full profile with credentials in local storage.
    this.saveUserToDB({ ...newUser, password: this.hashPassword(password) });

    return {
      success: true,
      message: "Signup successful",
      session: this.generateSession(newUser)
    };
  }

  static async emailLogin(email: string, password: string): Promise<{ success: boolean; message: string; session?: AuthSession }> {
    const users = this.getUsersFromDB();
    const userInDb = users.find(u => u.email === email);

    if (!userInDb) {
      return { success: false, message: "No account found with this email." };
    }

    if (userInDb.password !== this.hashPassword(password)) {
      return { success: false, message: "Invalid password." };
    }

    // Strip password before returning user
    const { password: _, ...userProfile } = userInDb;
    return {
      success: true,
      message: "Login successful",
      session: this.generateSession(userProfile as UserProfile)
    };
  }

  static async socialLogin(provider: 'GOOGLE' | 'FACEBOOK'): Promise<{ success: boolean; session?: AuthSession; message: string }> {
    // Simulate OAuth Delay
    await new Promise(r => setTimeout(r, 1200));

    // Simulated payload from OAuth
    const mockEmail = provider === 'GOOGLE' ? 'player.pro@gmail.com' : 'fan.sports@facebook.com';
    const mockName = provider === 'GOOGLE' ? 'Google Player' : 'Facebook Fan';

    const users = this.getUsersFromDB();
    let user = users.find(u => u.email === mockEmail);

    if (!user) {
      user = this.createUserProfile(mockEmail, provider);
      user.username = mockName;
      user.ageVerified = true; // OAuth users often pre-verified for age by provider
      user.isEmailVerified = true;
      this.saveUserToDB(user);
    }

    return {
      success: true,
      message: `${provider} login successful`,
      session: this.generateSession(user as UserProfile)
    };
  }

  private static generateSession(user: UserProfile): AuthSession {
    return {
      accessToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9." + btoa(JSON.stringify(user)) + "." + Math.random().toString(36).substr(2),
      refreshToken: "rt_" + Math.random().toString(36).substr(2),
      expiresAt: Date.now() + 3600000,
      user
    };
  }

  private static createUserProfile(email: string, provider: UserProfile['provider']): UserProfile {
    return {
      id: `u_${Math.random().toString(36).substr(2, 5)}`,
      username: email.split('@')[0],
      email: email,
      dob: '2000-01-01',
      ageVerified: false,
      role: email.includes('admin') ? 'ADMIN' : 'USER',
      walletBalance: 0,
      unutilizedBalance: 0,
      winningsBalance: 0,
      bonusBalance: 25,
      totalTdsPaid: 0,
      kycStatus: 'NOT_STARTED',
      provider: provider,
      isEmailVerified: provider !== 'EMAIL',
      referralData: {
        code: (email.slice(0, 3) + Math.floor(1000 + Math.random() * 9000)).toUpperCase(),
        totalReferrals: 0,
        bonusEarned: 0
      },
      activeDevices: [{
        deviceId: 'BROWSER_' + Date.now(),
        lastLogin: new Date().toISOString(),
        ip: '103.xxx.xx.x'
      }],
      lossStreakCount: 0,
      isAccountFrozen: false,
      isNewUser: true,
      totalInvested: 0,
      totalWinnings: 0,
      consentLogs: []
    };
  }

  static async requestOTP(target: string, type: 'EMAIL' | 'PHONE'): Promise<{ success: boolean; message: string; challenge?: OTPChallenge }> {
    if (Security.isRateLimited(`otp_${target}`)) return { success: false, message: "Too many attempts." };

    const challenge: OTPChallenge = {
      id: Math.random().toString(36).substr(2, 9),
      target,
      type,
      expiry: Date.now() + 300000,
      retryCount: 0,
      cooldownUntil: Date.now() + 60000
    };

    this.activeOTP.set(target, challenge);
    console.log(`[DEBUG] OTP: 123456`);
    return { success: true, message: "OTP sent successfully", challenge };
  }

  static async verifyOTP(target: string, code: string, deviceId: string): Promise<{ success: boolean; session?: AuthSession; message: string }> {
    const challenge = this.activeOTP.get(target);
    if (!challenge || code !== "123456") return { success: false, message: "Invalid OTP." };

    const users = this.getUsersFromDB();
    let user = users.find(u => (challenge.type === 'EMAIL' ? u.email === target : u.phone === target));

    if (!user) {
      user = this.createUserProfile(challenge.type === 'EMAIL' ? target : `user_${Date.now()}@fantasypro.com`, 'OTP');
      if (challenge.type === 'PHONE') user.phone = target;
      this.saveUserToDB(user);
    }

    return { 
      success: true, 
      session: this.generateSession(user as UserProfile), 
      message: "Success" 
    };
  }
}
