
import { PointSystem, UserTeam, Player } from '../types';

export class RuleEngine {
  private static currentSystem: PointSystem = {
    version: "2025.01",
    rules: {
      RUN: 1,
      WICKET: 25,
      CATCH: 8,
      BOUNDARY_BONUS: 1,
      SIX_BONUS: 2,
      MAIDEN_OVER: 12,
      STUMPING: 12,
      CAPTAIN_MULT: 2,
      VC_MULT: 1.5
    }
  };

  static calculatePoints(team: UserTeam, players: Player[]): number {
    let total = 0;
    const r = this.currentSystem.rules;

    team.playerIds.forEach(pid => {
      const p = players.find(x => x.id === pid);
      if (p) {
        let pts = p.points;
        if (pid === team.captainId) pts *= r.CAPTAIN_MULT;
        else if (pid === team.viceCaptainId) pts *= r.VC_MULT;
        total += pts;
      }
    });

    return total;
  }

  static getPointSystem() {
    return this.currentSystem;
  }
}
