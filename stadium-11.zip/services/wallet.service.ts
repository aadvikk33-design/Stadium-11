
import { UserProfile, Transaction, TransactionType } from '../types';

/**
 * DOUBLE-ENTRY BOOKKEEPING SERVICE
 * Implements strict balance check, atomic deducts, and Indian Tax (TDS) compliance.
 */
export class WalletService {
  private static TDS_THRESHOLD = 10000;
  private static TDS_RATE = 0.30; // 30% Flat Tax

  /**
   * Order: Bonus (max 10%) -> Unutilized -> Winnings
   */
  static processEntryFee(user: UserProfile, fee: number): { updatedUser: UserProfile, transaction: Transaction } {
    if (user.walletBalance < fee) {
      throw new Error("Insufficient Funds");
    }

    let remaining = fee;
    let bonusUsed = 0;
    let unutilizedUsed = 0;
    let winningsUsed = 0;

    const maxBonus = Math.min(fee * 0.1, user.bonusBalance);
    bonusUsed = parseFloat(maxBonus.toFixed(2));
    remaining -= bonusUsed;

    unutilizedUsed = Math.min(remaining, user.unutilizedBalance);
    unutilizedUsed = parseFloat(unutilizedUsed.toFixed(2));
    remaining -= unutilizedUsed;

    winningsUsed = parseFloat(remaining.toFixed(2));
    
    const updatedUser: UserProfile = {
      ...user,
      bonusBalance: parseFloat((user.bonusBalance - bonusUsed).toFixed(2)),
      unutilizedBalance: parseFloat((user.unutilizedBalance - unutilizedUsed).toFixed(2)),
      winningsBalance: parseFloat((user.winningsBalance - winningsUsed).toFixed(2)),
      walletBalance: parseFloat((user.walletBalance - fee).toFixed(2)),
      totalInvested: (user.totalInvested || 0) + fee
    };

    const transaction: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      amount: fee,
      netAmount: fee,
      type: 'DEBIT',
      description: 'Contest Entry Fee',
      timestamp: new Date().toISOString(),
      status: 'SUCCESS',
      referenceId: 'CONTEST_' + Date.now(),
      breakdown: {
        bonusUsed,
        unutilizedUsed,
        winningsUsed
      }
    };

    return { updatedUser, transaction };
  }

  /**
   * Credits winnings and handles automatic TDS deduction if applicable.
   */
  static creditWinnings(user: UserProfile, amount: number, contestId: string): { updatedUser: UserProfile, transaction: Transaction } {
    let tdsAmount = 0;
    let netWinning = amount;

    // TDS Compliance: Winnings > 10,000 are taxed at 30%
    if (amount >= this.TDS_THRESHOLD) {
      tdsAmount = parseFloat((amount * this.TDS_RATE).toFixed(2));
      netWinning = amount - tdsAmount;
    }

    const updatedUser: UserProfile = {
      ...user,
      winningsBalance: parseFloat((user.winningsBalance + netWinning).toFixed(2)),
      walletBalance: parseFloat((user.walletBalance + netWinning).toFixed(2)),
      totalWinnings: (user.totalWinnings || 0) + amount,
      totalTdsPaid: (user.totalTdsPaid || 0) + tdsAmount
    };

    const transaction: Transaction = {
      id: `win_${Math.random().toString(36).substr(2, 9)}`,
      amount: amount,
      tdsAmount: tdsAmount,
      netAmount: netWinning,
      type: 'WINNINGS',
      description: `Winnings: Contest #${contestId}${tdsAmount > 0 ? ' (Net of 30% TDS)' : ''}`,
      timestamp: new Date().toISOString(),
      status: 'SUCCESS',
      referenceId: contestId
    };

    return { updatedUser, transaction };
  }
}
