
import React, { useState, useEffect } from 'react';
import { UserTeam, JoinedContest } from '../types';
import { LeaderboardService, LeaderboardEntry } from '../services/leaderboard.service';
import { MOCK_PLAYERS } from '../data/mockData';

interface LeaderboardProps {
  userTeams: UserTeam[];
  joinedContests: JoinedContest[];
}

const Leaderboard: React.FC<LeaderboardProps> = ({ userTeams, joinedContests }) => {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const refreshRankings = () => {
      const matchTeams = userTeams.filter(ut => 
        joinedContests.some(jc => jc.teamId === ut.id)
      );

      const newRankings = LeaderboardService.generateLiveRankings(matchTeams, MOCK_PLAYERS);
      setEntries(newRankings);
      setLoading(false);
    };

    refreshRankings();
    const interval = setInterval(refreshRankings, 10000);
    return () => clearInterval(interval);
  }, [userTeams, joinedContests]);

  const top3 = entries.slice(0, 3);
  const remaining = entries.slice(3);
  const userEntry = entries.find(e => e.isUser);

  if (loading) return (
    <div className="p-20 text-center">
       <div className="animate-spin h-10 w-10 border-4 border-red-600 border-t-transparent rounded-full mx-auto mb-4"></div>
       <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Validating Shared Ranks...</p>
    </div>
  );

  return (
    <div className="space-y-6 pb-32">
      <div className="bg-gradient-to-br from-red-800 via-red-900 to-black p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-5">
           <i className="fas fa-trophy text-[10rem]"></i>
        </div>
        
        <div className="text-center mb-10">
          <h2 className="text-3xl font-black text-white tracking-tighter uppercase">Live Rankings</h2>
          <p className="text-[9px] text-red-400 font-black uppercase tracking-[0.3em]">Audited Competition Points</p>
        </div>

        <div className="flex items-end justify-center space-x-2 md:space-x-6 relative z-10">
          {top3[1] && (
            <div className="flex flex-col items-center group">
              <div className="w-16 h-16 rounded-full border-4 border-gray-400/50 overflow-hidden mb-3 shadow-xl group-hover:scale-110 transition-transform">
                <img src={top3[1].avatar} alt="" />
              </div>
              <p className="text-[10px] font-black text-white/80 mb-1 truncate w-16 text-center">{top3[1].userName}</p>
              <div className="h-20 w-16 bg-white/10 backdrop-blur-md rounded-t-2xl flex flex-col items-center justify-center">
                 <span className="font-black text-3xl text-white/20">{top3[1].rank}</span>
              </div>
            </div>
          )}
          {top3[0] && (
            <div className="flex flex-col items-center group">
              <div className="relative">
                <i className="fas fa-crown absolute -top-5 left-1/2 -translate-x-1/2 text-yellow-400 text-2xl animate-bounce"></i>
                <div className="w-24 h-24 rounded-full border-4 border-yellow-400 overflow-hidden mb-3 shadow-2xl group-hover:scale-110 transition-transform">
                  <img src={top3[0].avatar} alt="" />
                </div>
              </div>
              <p className="text-[11px] font-black text-white mb-1 truncate w-20 text-center">{top3[0].userName}</p>
              <div className="h-32 w-24 bg-white/20 backdrop-blur-md rounded-t-2xl flex flex-col items-center justify-center">
                 <span className="font-black text-5xl text-white/30">{top3[0].rank}</span>
              </div>
            </div>
          )}
          {top3[2] && (
            <div className="flex flex-col items-center group">
              <div className="w-16 h-16 rounded-full border-4 border-orange-600/50 overflow-hidden mb-3 shadow-xl group-hover:scale-110 transition-transform">
                <img src={top3[2].avatar} alt="" />
              </div>
              <p className="text-[10px] font-black text-white/80 mb-1 truncate w-16 text-center">{top3[2].userName}</p>
              <div className="h-16 w-16 bg-white/5 backdrop-blur-md rounded-t-2xl flex flex-col items-center justify-center">
                 <span className="font-black text-2xl text-white/10">{top3[2].rank}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden">
        <div className="px-6 py-4 bg-gray-50 border-b border-gray-100 flex justify-between text-[10px] font-black text-gray-400 uppercase tracking-widest">
          <span>Rank & Strategist</span>
          <span>Points</span>
        </div>
        <div className="divide-y divide-gray-50 max-h-[50vh] overflow-y-auto no-scrollbar">
          {remaining.map((e) => (
            <div key={e.teamId} className={`p-5 flex justify-between items-center transition-all ${e.isUser ? 'bg-red-50' : 'bg-white'}`}>
               <div className="flex items-center space-x-4">
                 <div className="w-8 flex flex-col items-center">
                    <span className="font-black text-sm text-gray-900">{e.rank}</span>
                    {e.isTie && <span className="text-[6px] font-black text-gray-400 uppercase leading-none">(Joint)</span>}
                 </div>
                 <img src={e.avatar} className="w-10 h-10 rounded-xl border border-gray-100" />
                 <div>
                   <p className="font-black text-gray-900 text-sm">{e.userName}</p>
                   <div className="flex items-center space-x-1">
                      {e.movement === 'UP' && <i className="fas fa-caret-up text-green-500 text-xs"></i>}
                      {e.movement === 'DOWN' && <i className="fas fa-caret-down text-red-500 text-xs"></i>}
                      <span className="text-[9px] font-black text-gray-400 uppercase">Team 1</span>
                   </div>
                 </div>
               </div>
               <div className="text-right">
                 <p className="font-black text-gray-900">{e.points.toFixed(1)}</p>
                 <p className="text-[9px] text-gray-400 font-black uppercase">Pts</p>
               </div>
            </div>
          ))}
        </div>
      </div>

      {userEntry && (
        <div className="fixed bottom-24 left-4 right-4 max-w-2xl mx-auto bg-gray-950 text-white p-6 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-white/10 flex justify-between items-center animate-in slide-in-from-bottom-5">
           <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-2xl bg-red-600 flex items-center justify-center font-black">YOU</div>
              <div>
                <p className="font-black text-sm">Best Team Rank</p>
                <p className="text-[9px] text-green-400 font-black uppercase">Standard Competition Order</p>
              </div>
           </div>
           <div className="flex space-x-8">
              <div className="text-right">
                <p className="text-[9px] text-gray-500 font-black uppercase">My Rank</p>
                <p className="text-2xl font-black text-yellow-400">#{userEntry.rank}</p>
              </div>
              <div className="text-right border-l border-white/10 pl-8">
                <p className="text-[9px] text-gray-500 font-black uppercase">Total Pts</p>
                <p className="text-2xl font-black">{userEntry.points.toFixed(1)}</p>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Leaderboard;
