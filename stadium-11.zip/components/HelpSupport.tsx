
import React from 'react';

const HelpSupport: React.FC = () => {
  const pointsRules = [
    { event: "Run", pts: "1", bonus: "" },
    { event: "Boundary Bonus", pts: "1", bonus: "" },
    { event: "Six Bonus", pts: "2", bonus: "" },
    { event: "Wicket", pts: "25", bonus: "Excl. Run Out" },
    { event: "Maiden Over", pts: "12", bonus: "T20" },
    { event: "Catch", pts: "8", bonus: "" },
    { event: "Stumping/Run Out", pts: "12", bonus: "" },
  ];

  return (
    <div className="space-y-6 pb-20">
      <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
        <h2 className="text-2xl font-black text-gray-900 tracking-tighter mb-6">How to Play</h2>
        <div className="space-y-4">
          <div className="flex items-start space-x-4">
             <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center font-black flex-shrink-0">1</div>
             <p className="text-sm font-bold text-gray-600 leading-relaxed">Select a match from the upcoming list.</p>
          </div>
          <div className="flex items-start space-x-4">
             <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center font-black flex-shrink-0">2</div>
             <p className="text-sm font-bold text-gray-600 leading-relaxed">Create your team of 11 players within 100 credits.</p>
          </div>
          <div className="flex items-start space-x-4">
             <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center font-black flex-shrink-0">3</div>
             <p className="text-sm font-bold text-gray-600 leading-relaxed">Choose a Captain (2x Points) and Vice-Captain (1.5x Points).</p>
          </div>
          <div className="flex items-start space-x-4">
             <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center font-black flex-shrink-0">4</div>
             <p className="text-sm font-bold text-gray-600 leading-relaxed">Join contests and follow the live match to track your ranking.</p>
          </div>
        </div>
      </div>

      <div className="bg-gray-950 p-8 rounded-[2.5rem] text-white shadow-2xl">
        <h3 className="text-xl font-black mb-6">Point System (T20)</h3>
        <div className="space-y-3">
          {pointsRules.map((rule, i) => (
            <div key={i} className="flex justify-between items-center py-3 border-b border-white/5">
               <div>
                 <p className="font-black text-sm">{rule.event}</p>
                 {rule.bonus && <p className="text-[9px] text-gray-500 font-bold uppercase">{rule.bonus}</p>}
               </div>
               <p className="font-black text-red-500">+{rule.pts} Pts</p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100">
        <h3 className="text-xl font-black mb-6">Contact Support</h3>
        <div className="grid grid-cols-2 gap-4">
          <a href="mailto:support@fantasypro.com" className="p-6 bg-gray-50 rounded-3xl text-center hover:bg-red-50 transition-colors">
             <i className="fas fa-envelope text-2xl text-red-600 mb-3"></i>
             <p className="text-[10px] font-black uppercase">Email Us</p>
          </a>
          <div className="p-6 bg-gray-50 rounded-3xl text-center">
             <i className="fas fa-comment-dots text-2xl text-gray-400 mb-3"></i>
             <p className="text-[10px] font-black uppercase text-gray-400">Live Chat</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HelpSupport;
