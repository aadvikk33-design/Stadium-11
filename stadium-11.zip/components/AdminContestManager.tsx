
import React, { useState } from 'react';
import { Contest, Match, Player, UserProfile, UserTeam, JoinedContest } from '../types';
import { AdminService } from '../services/admin.service';
import { MOCK_PLAYERS } from '../data/mockData';

interface AdminContestManagerProps {
  contests: Contest[];
  matches: Match[];
  allUsers: UserProfile[];
  userTeams: UserTeam[];
  joinedContests: JoinedContest[];
  onUpdate: (data: any) => void;
}

const AdminContestManager: React.FC<AdminContestManagerProps> = ({ contests, matches, allUsers, userTeams, joinedContests, onUpdate }) => {
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSettle = async (contest: Contest) => {
    if (!window.confirm(`Are you sure you want to distribute prizes for ${contest.name}? This action is irreversible.`)) return;
    
    setIsProcessing(true);
    try {
      // For demo, we use MOCK_PLAYERS as the source of truth for result points
      const result = await AdminService.settleContest(
        contest, 
        joinedContests, 
        userTeams, 
        MOCK_PLAYERS, 
        allUsers
      );
      
      alert(`Successfully settled! ${result.transactions.length} payouts processed.`);
      onUpdate(result);
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="bg-white p-8 rounded-[3rem] shadow-sm border border-gray-100">
        <div className="flex items-center space-x-4 mb-8">
           <div className="w-14 h-14 bg-red-600 text-white rounded-2xl flex items-center justify-center text-2xl shadow-lg shadow-red-200">
              <i className="fas fa-gavel"></i>
           </div>
           <div>
              <h2 className="text-2xl font-black text-gray-900 tracking-tighter">Match Settlement</h2>
              <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Payout & P&L Control</p>
           </div>
        </div>

        <div className="space-y-4">
          {matches.map(match => (
            <div key={match.id} className="p-6 border-2 border-gray-50 rounded-[2.5rem] bg-gray-50/30">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center space-x-4">
                   <span className="font-black text-lg text-gray-900">{match.team1} vs {match.team2}</span>
                   <span className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${match.status === 'COMPLETED' ? 'bg-green-100 text-green-600' : 'bg-orange-100 text-orange-600'}`}>
                      {match.status}
                   </span>
                </div>
              </div>

              <div className="space-y-3">
                {contests.filter(c => c.matchId === match.id).map(contest => (
                  <div key={contest.id} className="flex justify-between items-center p-4 bg-white rounded-3xl border border-gray-100">
                     <div>
                        <p className="font-black text-sm text-gray-900">{contest.name}</p>
                        <p className="text-[9px] text-gray-400 font-bold uppercase">
                          Pool: ₹{contest.prizePool} • {contest.filledSpots}/{contest.totalSpots} Joined
                        </p>
                     </div>
                     <button 
                        disabled={isProcessing || contest.settlementStatus === 'SETTLED' || match.status !== 'COMPLETED'}
                        onClick={() => handleSettle(contest)}
                        className={`px-6 py-3 rounded-2xl text-[9px] font-black uppercase tracking-widest transition-all ${
                          contest.settlementStatus === 'SETTLED' ? 'bg-green-50 text-green-600' : 'bg-gray-900 text-white hover:bg-black active:scale-95 disabled:opacity-30'
                        }`}
                     >
                        {contest.settlementStatus === 'SETTLED' ? <><i className="fas fa-check mr-2"></i>Paid Out</> : 'Process Payouts'}
                     </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-yellow-50 p-8 rounded-[2.5rem] border border-yellow-100 flex items-start space-x-6">
         <div className="w-12 h-12 bg-yellow-100 text-yellow-600 rounded-2xl flex items-center justify-center flex-shrink-0 text-xl">
            <i className="fas fa-shield-exclamation"></i>
         </div>
         <div>
            <h4 className="font-black text-sm mb-1 tracking-tight text-yellow-900 uppercase">Settlement Caution</h4>
            <p className="text-[9px] text-yellow-700 font-bold uppercase leading-relaxed">
              Once payout is triggered, money is moved from Escrow to User Winnings instantly. 
              Always cross-verify actual player scores with official match data before settlement.
            </p>
         </div>
      </div>
    </div>
  );
};

export default AdminContestManager;
