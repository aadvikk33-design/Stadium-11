
import React, { useState } from 'react';
import { UserProfile, KYCDetails } from '../types';
import { ComplianceService } from '../services/compliance.service';

interface KYCProps {
  user: UserProfile;
  onUpdate: (updatedUser: UserProfile) => void;
}

const KYC: React.FC<KYCProps> = ({ user, onUpdate }) => {
  const [step, setStep] = useState<'INFO' | 'UPLOAD' | 'PROCESSING'>('INFO');
  const [pan, setPan] = useState(user.kycDetails?.panNumber || '');
  const [name, setName] = useState(user.kycDetails?.fullName || '');
  const [dob, setDob] = useState(user.kycDetails?.dob || user.dob);
  const [state, setState] = useState(user.kycDetails?.state || 'Delhi');
  const [panImage, setPanImage] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);

  const getProgress = () => {
    if (user.kycStatus === 'VERIFIED') return 100;
    if (user.kycStatus === 'SUBMITTED' || user.kycStatus === 'PENDING') return 75;
    if (step === 'UPLOAD') return 50;
    if (step === 'INFO') return 25;
    return 0;
  };

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!ComplianceService.validatePAN(pan)) {
      setError("Invalid PAN Format. Example: ABCDE1234F");
      return;
    }

    if (ComplianceService.calculateAge(dob) < 18) {
      setError("PAN DOB shows age under 18. KYC rejected.");
      return;
    }

    if (!ComplianceService.isStateAllowed(state)) {
      setError(`Real money contests are not allowed in ${state} due to local laws.`);
      return;
    }

    setStep('UPLOAD');
  };

  const handleFinalSubmit = () => {
    if (!panImage) {
      setError("Please upload your PAN card image.");
      return;
    }

    setStep('PROCESSING');
    
    // Simulate API submission
    setTimeout(() => {
      const updatedUser: UserProfile = {
        ...user,
        kycStatus: 'SUBMITTED',
        kycDetails: { 
          panNumber: pan, 
          fullName: name, 
          dob, 
          state, 
          status: 'SUBMITTED',
          submittedAt: new Date().toISOString()
        }
      };
      onUpdate(updatedUser);
    }, 2000);
  };

  if (user.kycStatus === 'VERIFIED') {
    return (
      <div className="space-y-6">
        <div className="bg-white p-10 rounded-[3rem] shadow-sm border border-gray-100 text-center">
           <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center text-4xl mx-auto mb-6">
              <i className="fas fa-check-circle"></i>
           </div>
           <h2 className="text-3xl font-black text-gray-900 tracking-tighter">KYC Verified</h2>
           <p className="text-[10px] text-green-600 font-black uppercase tracking-widest mt-2 mb-8">Identity confirmed • Unlimited access</p>
           
           <div className="space-y-3 max-w-xs mx-auto">
              <div className="flex justify-between p-4 bg-gray-50 rounded-2xl">
                 <span className="text-[10px] font-black text-gray-400 uppercase">PAN</span>
                 <span className="text-[10px] font-black text-gray-900">{user.kycDetails?.panNumber}</span>
              </div>
              <div className="flex justify-between p-4 bg-gray-50 rounded-2xl">
                 <span className="text-[10px] font-black text-gray-400 uppercase">Name</span>
                 <span className="text-[10px] font-black text-gray-900">{user.kycDetails?.fullName}</span>
              </div>
           </div>
        </div>
      </div>
    );
  }

  if (user.kycStatus === 'SUBMITTED' || user.kycStatus === 'PENDING') {
    return (
      <div className="space-y-6">
        <div className="bg-white p-10 rounded-[3rem] shadow-sm border border-gray-100 text-center">
           <div className="w-20 h-20 bg-blue-50 text-blue-500 rounded-full flex items-center justify-center text-4xl mx-auto mb-6">
              <i className="fas fa-clock animate-pulse"></i>
           </div>
           <h2 className="text-3xl font-black text-gray-900 tracking-tighter">Verification in Progress</h2>
           <p className="text-sm text-gray-400 font-bold mt-4 leading-relaxed max-w-xs mx-auto">
             Our compliance team is reviewing your documents. This usually takes 2-4 hours.
           </p>
           <div className="mt-10 p-4 bg-blue-50 text-blue-600 rounded-2xl text-[9px] font-black uppercase tracking-widest border border-blue-100">
             Reference ID: KYC_{Math.random().toString(36).substr(2, 6).toUpperCase()}
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white p-8 rounded-[3rem] shadow-sm border border-gray-100">
        {/* Progress Bar */}
        <div className="mb-10">
          <div className="flex justify-between text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">
             <span>Trust Verification</span>
             <span>{getProgress()}%</span>
          </div>
          <div className="w-full h-2 bg-gray-50 rounded-full overflow-hidden">
             <div className="h-full bg-red-600 transition-all duration-500" style={{ width: `${getProgress()}%` }}></div>
          </div>
        </div>

        {step === 'INFO' && (
          <form onSubmit={handleDetailsSubmit} className="space-y-6 animate-in fade-in">
            <div className="flex items-center space-x-4 mb-8">
              <div className="w-14 h-14 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center text-2xl">
                  <i className="fas fa-id-card"></i>
              </div>
              <div>
                  <h2 className="text-2xl font-black text-gray-900 tracking-tighter">Step 1: Details</h2>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Enter PAN Information</p>
              </div>
            </div>

            {error && (
              <div className="p-4 bg-red-50 text-red-600 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-red-100">
                {error}
              </div>
            )}
            
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">Full Name (As on PAN)</label>
                <input 
                  type="text" required value={name} onChange={e => setName(e.target.value)}
                  className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl font-black focus:ring-2 focus:ring-red-600 outline-none"
                  placeholder="JOHN DOE"
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">PAN Card Number</label>
                <input 
                  type="text" required value={pan} maxLength={10} onChange={e => setPan(e.target.value.toUpperCase())}
                  className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl font-black focus:ring-2 focus:ring-red-600 outline-none uppercase"
                  placeholder="ABCDE1234F"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">PAN Date of Birth</label>
                  <input 
                    type="date" required value={dob} onChange={e => setDob(e.target.value)}
                    className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl font-black focus:ring-2 focus:ring-red-600 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">State</label>
                  <select 
                    value={state} onChange={e => setState(e.target.value)}
                    className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl font-black focus:ring-2 focus:ring-red-600 outline-none"
                  >
                    <option>Delhi</option>
                    <option>Maharashtra</option>
                    <option>Karnataka</option>
                    <option>Uttar Pradesh</option>
                    <option>Rajasthan</option>
                    <option>Tamil Nadu</option>
                  </select>
                </div>
              </div>
            </div>

            <button className="w-full py-5 bg-gray-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-black transition-all active:scale-95">
              Continue to Upload
            </button>
          </form>
        )}

        {step === 'UPLOAD' && (
          <div className="space-y-6 animate-in slide-in-from-right-4">
            <div className="flex items-center space-x-4 mb-8">
              <div className="w-14 h-14 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center text-2xl">
                  <i className="fas fa-camera"></i>
              </div>
              <div>
                  <h2 className="text-2xl font-black text-gray-900 tracking-tighter">Step 2: Upload</h2>
                  <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Photograph of PAN Front</p>
              </div>
            </div>

            {error && (
              <div className="p-4 bg-red-50 text-red-600 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-red-100">
                {error}
              </div>
            )}

            <div className="border-4 border-dashed border-gray-100 rounded-[2rem] p-10 text-center hover:border-red-600 transition-all group">
               {!panImage ? (
                 <label className="cursor-pointer block">
                    <i className="fas fa-cloud-upload-alt text-4xl text-gray-200 mb-4 group-hover:text-red-600"></i>
                    <p className="text-sm font-bold text-gray-400 mb-2">Click to select PAN image</p>
                    <p className="text-[9px] text-gray-300 font-black uppercase">JPG, PNG allowed (Max 5MB)</p>
                    <input type="file" className="hidden" accept="image/*" onChange={e => setPanImage(e.target.files?.[0] || null)} />
                 </label>
               ) : (
                 <div className="relative">
                    <div className="bg-gray-50 rounded-2xl p-4 flex items-center space-x-4">
                       <i className="fas fa-file-image text-2xl text-red-600"></i>
                       <div className="text-left overflow-hidden">
                          <p className="font-black text-gray-900 text-xs truncate">{panImage.name}</p>
                          <p className="text-[8px] text-gray-400 font-black uppercase">{(panImage.size / 1024).toFixed(0)} KB</p>
                       </div>
                    </div>
                    <button onClick={() => setPanImage(null)} className="absolute -top-3 -right-3 w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg"><i className="fas fa-times"></i></button>
                 </div>
               )}
            </div>

            <div className="flex space-x-4">
               <button onClick={() => setStep('INFO')} className="flex-1 py-5 bg-white border-2 border-gray-100 text-gray-400 rounded-2xl font-black text-xs uppercase tracking-widest">Back</button>
               <button onClick={handleFinalSubmit} className="flex-[2] py-5 bg-red-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-red-600/20 active:scale-95 transition-all">Submit KYC</button>
            </div>
          </div>
        )}

        {step === 'PROCESSING' && (
           <div className="p-20 text-center animate-in zoom-in-95">
              <div className="w-16 h-16 border-4 border-red-600 border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
              <h2 className="text-2xl font-black text-gray-900 tracking-tighter">Uploading Securely</h2>
              <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest mt-2">Encrypting & saving data...</p>
           </div>
        )}
      </div>

      <div className="bg-blue-950 p-8 rounded-[2.5rem] text-white flex items-start space-x-6">
         <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center flex-shrink-0 text-xl">
            <i className="fas fa-shield-halved"></i>
         </div>
         <div>
            <h4 className="font-black text-sm mb-1 tracking-tight">Your Privacy Matters</h4>
            <p className="text-[10px] text-blue-300 font-bold uppercase leading-relaxed">
              We encrypt your data using AES-256 standards. Your documents are only accessible to authorized verification agents.
            </p>
         </div>
      </div>
    </div>
  );
};

export default KYC;
