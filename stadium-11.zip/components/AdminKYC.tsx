
import React, { useState } from 'react';
import { UserProfile } from '../types';

interface AdminKYCProps {
  user: UserProfile;
}

const AdminKYC: React.FC<AdminKYCProps> = ({ user }) => {
  // Mock data for submitted KYCs
  const [submissions, setSubmissions] = useState([
    { id: '1', username: 'Ramesh_Kumar', pan: 'ABCDE1234F', fullName: 'RAMESH KUMAR', dob: '1995-05-15', state: 'Delhi', submittedAt: '2025-05-10T10:30:00Z', status: 'SUBMITTED' },
    { id: '2', username: 'Suresh_Patel', pan: 'FGHIJ5678K', fullName: 'SURESH PATEL', dob: '2010-10-10', state: 'Maharashtra', submittedAt: '2025-05-10T11:45:00Z', status: 'SUBMITTED' },
  ]);

  const handleAction = (id: string, action: 'APPROVE' | 'REJECT') => {
    setSubmissions(prev => prev.filter(s => s.id !== id));
    alert(`Submission ${id} has been ${action}D`);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-8 rounded-[3rem] shadow-sm border border-gray-100">
        <div className="flex items-center space-x-4 mb-8">
           <div className="w-14 h-14 bg-gray-950 text-white rounded-2xl flex items-center justify-center text-2xl">
              <i className="fas fa-user-shield"></i>
           </div>
           <div>
              <h2 className="text-2xl font-black text-gray-900 tracking-tighter">Compliance Dashboard</h2>
              <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">KYC Approval Queue</p>
           </div>
        </div>

        {submissions.length === 0 ? (
          <div className="p-20 text-center bg-gray-50 rounded-[2rem] border border-dashed border-gray-200">
             <i className="fas fa-check-double text-4xl text-gray-200 mb-4"></i>
             <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Queue Clear</p>
          </div>
        ) : (
          <div className="space-y-4">
            {submissions.map(sub => {
              const age = new Date().getFullYear() - new Date(sub.dob).getFullYear();
              const isMinor = age < 18;

              return (
                <div key={sub.id} className="p-6 border-2 border-gray-50 rounded-[2.5rem] bg-gray-50/30 flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0">
                  <div className="flex items-center space-x-6">
                     <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center border-2 border-gray-50">
                        <i className="fas fa-user-tie text-2xl text-gray-400"></i>
                     </div>
                     <div>
                        <p className="font-black text-gray-900 uppercase tracking-tighter mb-1">{sub.fullName}</p>
                        <div className="flex items-center space-x-3">
                           <span className="text-[8px] font-black text-gray-400 bg-white px-2 py-1 rounded-full">{sub.pan}</span>
                           <span className={`text-[8px] font-black px-2 py-1 rounded-full ${isMinor ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                             Age: {age} {isMinor && '(Underage!)'}
                           </span>
                        </div>
                     </div>
                  </div>

                  <div className="flex space-x-2 w-full md:w-auto">
                     <button 
                        onClick={() => handleAction(sub.id, 'REJECT')}
                        className="flex-1 px-6 py-4 bg-white border border-red-100 text-red-600 rounded-2xl text-[10px] font-black uppercase hover:bg-red-50 transition-all"
                     >
                        Reject
                     </button>
                     <button 
                        disabled={isMinor}
                        onClick={() => handleAction(sub.id, 'APPROVE')}
                        className={`flex-1 px-8 py-4 rounded-2xl text-[10px] font-black uppercase shadow-lg transition-all ${isMinor ? 'bg-gray-100 text-gray-300' : 'bg-green-600 text-white hover:bg-green-700'}`}
                     >
                        Approve
                     </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminKYC;
