
import React, { useState } from 'react';
import { UserProfile } from '../types';

interface ResponsiblePlayProps {
  user: UserProfile;
  onUpdate: (updatedUser: UserProfile) => void;
}

const ResponsiblePlay: React.FC<ResponsiblePlayProps> = ({ user, onUpdate }) => {
  const [excludeDays, setExcludeDays] = useState(1);

  const handleSelfExclusion = () => {
    const until = new Date();
    until.setDate(until.getDate() + excludeDays);
    
    if (window.confirm(`Are you sure? You will be locked out of the app until ${until.toLocaleDateString()}.`)) {
      onUpdate({
        ...user,
        selfExclusionUntil: until.toISOString(),
        isAccountFrozen: true
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-gray-100">
        <div className="flex items-center space-x-4 mb-6">
          <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
            <i className="fas fa-shield-heart text-xl"></i>
          </div>
          <h2 className="text-2xl font-black text-gray-900 tracking-tighter">Responsible Play</h2>
        </div>

        <p className="text-sm text-gray-500 font-bold leading-relaxed mb-8">
          Fantasy sports should be fun and entertaining. If you feel like you're losing control, we're here to help you stay safe.
        </p>

        <div className="space-y-4">
          <div className="p-6 bg-red-50 rounded-3xl border border-red-100">
            <h3 className="font-black text-red-900 mb-2 uppercase text-xs">Self-Exclusion</h3>
            <p className="text-[10px] text-red-600 font-bold mb-4">Temporarily freeze your account. You won't be able to login or join contests.</p>
            
            <div className="flex space-x-2 mb-4">
              {[1, 3, 7, 30].map(days => (
                <button 
                  key={days}
                  onClick={() => setExcludeDays(days)}
                  className={`flex-1 py-3 rounded-xl font-black text-[10px] transition-all ${excludeDays === days ? 'bg-red-600 text-white shadow-lg' : 'bg-white text-red-400'}`}
                >
                  {days}D
                </button>
              ))}
            </div>

            <button 
              onClick={handleSelfExclusion}
              className="w-full py-4 bg-red-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl active:scale-95 transition-all"
            >
              Freeze My Account
            </button>
          </div>

          <div className="p-6 bg-gray-50 rounded-3xl">
             <div className="flex justify-between items-center mb-2">
                <h3 className="font-black text-gray-900 uppercase text-xs">Daily Limit</h3>
                <span className="text-[10px] font-black text-gray-400">₹5,000 Max</span>
             </div>
             <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div className="h-full bg-blue-600" style={{ width: '20%' }}></div>
             </div>
             <p className="text-[9px] text-gray-400 font-bold mt-2 uppercase">Used ₹1,000 today</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResponsiblePlay;
