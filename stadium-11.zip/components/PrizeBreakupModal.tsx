
import React from 'react';
import { Contest } from '../types';
import { PrizeEngine } from '../services/prize.service';

interface PrizeBreakupModalProps {
  contest: Contest;
  onClose: () => void;
}

const PrizeBreakupModal: React.FC<PrizeBreakupModalProps> = ({ contest, onClose }) => {
  const prizeTable = PrizeEngine.getPrizeTable(contest);
  const netPool = PrizeEngine.getNetPrizePool(contest);
  const platformFee = PrizeEngine.getPlatformRake(contest);

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white w-full max-w-sm rounded-[2.5rem] overflow-hidden shadow-2xl">
        <div className="p-8 bg-gray-950 text-white relative">
           <button onClick={onClose} className="absolute top-6 right-6 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all">
             <i className="fas fa-times"></i>
           </button>
           <h3 className="text-2xl font-black tracking-tighter mb-1">Prize Structure</h3>
           <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Contest: {contest.name}</p>
        </div>

        <div className="p-6">
           <div className="bg-gray-50 rounded-3xl p-5 mb-6 border border-gray-100">
              <div className="flex justify-between items-center mb-4">
                 <span className="text-[10px] font-black text-gray-400 uppercase">Net Prize Pool</span>
                 <span className="text-xl font-black text-gray-900">₹{netPool.toLocaleString()}</span>
              </div>
              <div className="space-y-2 border-t border-gray-100 pt-4">
                 <div className="flex justify-between text-[9px] font-black uppercase">
                    <span className="text-gray-400">Platform Commission</span>
                    <span className="text-gray-900">{contest.rakePercentage}%</span>
                 </div>
                 <div className="flex justify-between text-[9px] font-black uppercase">
                    <span className="text-gray-400">Guaranteed</span>
                    <span className={contest.isGuaranteed ? 'text-green-600' : 'text-orange-600'}>{contest.isGuaranteed ? 'YES' : 'NO'}</span>
                 </div>
              </div>
           </div>

           <div className="max-h-60 overflow-y-auto no-scrollbar rounded-2xl border border-gray-100">
              <table className="w-full text-left">
                 <thead className="bg-gray-50 sticky top-0">
                    <tr>
                       <th className="px-5 py-3 text-[10px] font-black text-gray-400 uppercase tracking-widest">Rank</th>
                       <th className="px-5 py-3 text-[10px] font-black text-gray-400 uppercase tracking-widest text-right">Prize</th>
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-gray-50">
                    {prizeTable.map((row, i) => (
                       <tr key={i} className="hover:bg-gray-50/50 transition-colors">
                          <td className="px-5 py-4 font-black text-gray-900 text-sm tracking-tight">{row.rank}</td>
                          <td className="px-5 py-4 font-black text-gray-900 text-sm text-right">₹{row.amount.toLocaleString()}</td>
                       </tr>
                    ))}
                 </tbody>
              </table>
           </div>

           <p className="mt-6 text-[8px] text-gray-400 font-bold uppercase text-center leading-relaxed">
             * Prizes are split equally in case of ties. <br/>
             Final pool depends on total spots filled for non-guaranteed contests.
           </p>
        </div>

        <div className="p-6 bg-gray-50 border-t flex justify-center">
           <button 
             onClick={onClose}
             className="w-full py-4 bg-gray-950 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl active:scale-95 transition-all"
           >
             Close Breakup
           </button>
        </div>
      </div>
    </div>
  );
};

export default PrizeBreakupModal;
