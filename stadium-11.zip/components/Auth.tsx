
import React, { useState, useEffect } from 'react';
import { AuthService } from '../services/auth.service';
import { ComplianceService } from '../services/compliance.service';

interface AuthProps {
  onLogin: (session: any) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<'LOGIN' | 'SIGNUP'>('LOGIN');
  const [method, setMethod] = useState<'EMAIL' | 'OTP'>('EMAIL');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [dob, setDob] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState<'INPUT' | 'OTP_VERIFY'>('INPUT');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [consent, setConsent] = useState(false);

  const handleSocialLogin = async (provider: 'GOOGLE' | 'FACEBOOK') => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await AuthService.socialLogin(provider);
      if (result.success && result.session) {
        onLogin(result.session);
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError("Social login failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      if (mode === 'SIGNUP') {
        if (!ComplianceService.isAgeEligible(dob)) {
          setError("You must be 18+ to play.");
          setIsLoading(false);
          return;
        }
        if (!consent) {
          setError("Please accept terms and conditions.");
          setIsLoading(false);
          return;
        }
        const result = await AuthService.emailSignup(email, password, dob, username);
        if (result.success && result.session) onLogin(result.session);
        else setError(result.message);
      } else {
        const result = await AuthService.emailLogin(email, password);
        if (result.success && result.session) onLogin(result.session);
        else setError(result.message);
      }
    } catch (err) {
      setError("Authentication failed.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleRequestOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    const type = email.includes('@') ? 'EMAIL' : 'PHONE';
    const result = await AuthService.requestOTP(email, type);
    if (result.success) setStep('OTP_VERIFY');
    else setError(result.message);
    setIsLoading(false);
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    const result = await AuthService.verifyOTP(email, otp, "DEV_FINGERPRINT_123");
    if (result.success && result.session) onLogin(result.session);
    else setError(result.message);
    setIsLoading(false);
  };

  return (
    <div className="min-h-[90vh] flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md bg-white p-10 rounded-[3rem] shadow-2xl border border-gray-100 relative overflow-hidden">
        {/* Branding */}
        <div className="text-center mb-8">
          <div className="inline-block px-4 py-1.5 bg-red-50 text-red-600 rounded-full text-[9px] font-black uppercase tracking-widest mb-4">
            Official Gaming Platform
          </div>
          <h1 className="text-4xl font-black tracking-tighter text-gray-900 leading-none">
            FANTASY<span className="text-red-600">PRO</span>
          </h1>
          <p className="text-gray-400 font-bold mt-2 text-[10px] uppercase tracking-widest">{mode === 'LOGIN' ? 'Welcome Back' : 'Create New Account'}</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 text-red-600 rounded-2xl text-[10px] font-black uppercase border border-red-100 flex items-center animate-in fade-in">
            <i className="fas fa-exclamation-circle mr-3 text-lg"></i>
            {error}
          </div>
        )}

        {/* Social Buttons */}
        <div className="space-y-3 mb-8">
          <button 
            disabled={isLoading}
            onClick={() => handleSocialLogin('GOOGLE')}
            className="w-full py-4 bg-white border-2 border-gray-100 hover:border-gray-300 rounded-2xl flex items-center justify-center space-x-4 transition-all group active:scale-95 disabled:opacity-50"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5" alt="G" />
            <span className="text-xs font-black text-gray-700 uppercase tracking-widest">Login with Google</span>
          </button>
          <button 
            disabled={isLoading}
            onClick={() => handleSocialLogin('FACEBOOK')}
            className="w-full py-4 bg-blue-600 hover:bg-blue-700 rounded-2xl flex items-center justify-center space-x-4 transition-all active:scale-95 shadow-lg shadow-blue-100 disabled:opacity-50"
          >
            <i className="fab fa-facebook text-white text-lg"></i>
            <span className="text-xs font-black text-white uppercase tracking-widest">Login with Facebook</span>
          </button>
        </div>

        <div className="flex items-center space-x-4 mb-8">
          <div className="flex-grow h-px bg-gray-100"></div>
          <span className="text-[9px] font-black text-gray-300 uppercase tracking-widest">Or use email</span>
          <div className="flex-grow h-px bg-gray-100"></div>
        </div>

        {step === 'INPUT' ? (
          <form onSubmit={method === 'EMAIL' ? handleEmailAuth : handleRequestOTP} className="space-y-4">
            <div className="space-y-4">
              {mode === 'SIGNUP' && (
                <div className="animate-in slide-in-from-top-2">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">Username</label>
                  <input 
                    type="text" required value={username} onChange={e => setUsername(e.target.value)}
                    className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl font-black focus:ring-2 focus:ring-red-500 outline-none text-sm"
                    placeholder="CHAMPION_25"
                  />
                </div>
              )}
              
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">Email Address</label>
                <input 
                  type="email" required value={email} onChange={e => setEmail(e.target.value)}
                  className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl font-black focus:ring-2 focus:ring-red-500 outline-none text-sm"
                  placeholder="name@email.com"
                />
              </div>

              {method === 'EMAIL' && (
                <div className="animate-in fade-in">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">Password</label>
                  <input 
                    type="password" required value={password} onChange={e => setPassword(e.target.value)}
                    className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl font-black focus:ring-2 focus:ring-red-500 outline-none text-sm"
                    placeholder="••••••••"
                  />
                </div>
              )}

              {mode === 'SIGNUP' && (
                <div className="grid grid-cols-2 gap-4 animate-in fade-in">
                  <div className="col-span-2">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 px-1">Date of Birth</label>
                    <input 
                      type="date" required value={dob} onChange={e => setDob(e.target.value)}
                      className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl font-black focus:ring-2 focus:ring-red-500 outline-none text-sm"
                    />
                  </div>
                </div>
              )}
            </div>

            {mode === 'SIGNUP' && (
              <div className="flex items-start space-x-3 p-4 bg-gray-50 rounded-2xl border border-gray-100 animate-in fade-in">
                <input 
                  type="checkbox" id="consent" checked={consent} onChange={e => setConsent(e.target.checked)}
                  className="mt-1 w-4 h-4 rounded border-gray-300 text-red-600"
                />
                <label htmlFor="consent" className="text-[9px] font-bold text-gray-500 uppercase leading-relaxed">
                  I declare I am 18+ and accept <span className="text-red-600 underline">Terms</span> & <span className="text-red-600 underline">Policies</span>.
                </label>
              </div>
            )}

            <button 
              disabled={isLoading}
              className="w-full py-5 bg-gray-900 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl hover:bg-black transition-all active:scale-95 disabled:bg-gray-100"
            >
              {isLoading ? 'Processing...' : (method === 'OTP' ? 'Request OTP' : (mode === 'LOGIN' ? 'Login Now' : 'Create Account'))}
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerifyOTP} className="space-y-6 animate-in slide-in-from-right-4">
             <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4 px-1 text-center">Verify OTP Sent to Email</label>
              <input 
                type="text" maxLength={6} required autoFocus value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g, ''))}
                className="w-full tracking-[1em] text-center py-5 bg-gray-50 border border-gray-100 rounded-2xl font-black text-gray-900 focus:outline-none focus:ring-2 focus:ring-red-500 transition-all text-2xl"
                placeholder="------"
              />
            </div>
            <button 
              disabled={isLoading || otp.length !== 6}
              className="w-full py-5 bg-red-600 text-white rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl active:scale-95 disabled:opacity-50"
            >
              Verify & Play
            </button>
            <button type="button" onClick={() => setStep('INPUT')} className="w-full text-[10px] text-gray-400 font-black uppercase tracking-widest text-center">Back to login</button>
          </form>
        )}

        <div className="mt-8 text-center space-y-4">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
            {mode === 'LOGIN' ? "Don't have an account?" : "Already have an account?"}
          </p>
          <button 
            onClick={() => { setMode(mode === 'LOGIN' ? 'SIGNUP' : 'LOGIN'); setError(null); }}
            className="w-full py-4 border-2 border-gray-950 text-gray-950 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-gray-50 transition-all"
          >
            {mode === 'LOGIN' ? 'Switch to Sign Up' : 'Switch to Login'}
          </button>
          
          <button 
            onClick={() => { setMethod(method === 'EMAIL' ? 'OTP' : 'EMAIL'); setStep('INPUT'); setError(null); }}
            className="text-[9px] font-black text-red-600 uppercase tracking-widest underline hover:text-red-700"
          >
            {method === 'EMAIL' ? 'Use OTP Login instead' : 'Use Password Login instead'}
          </button>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-100 flex justify-center space-x-6 opacity-30 grayscale">
          <i className="fas fa-shield-halved text-2xl"></i>
          <i className="fab fa-cc-visa text-2xl"></i>
          <i className="fab fa-cc-mastercard text-2xl"></i>
        </div>
      </div>
    </div>
  );
};

export default Auth;
