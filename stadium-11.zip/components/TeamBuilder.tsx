
import React, { useState, useMemo, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Player, PlayerRole, UserTeam, UserProfile, Match, PlayerLifecycle } from '../types';
import { MOCK_PLAYERS, MOCK_MATCHES } from '../data/mockData';
import { LockService } from '../services/lock.service';
import { ComplianceEngine } from '../lib/compliance';

interface TeamBuilderProps {
  onSave: (team: UserTeam) => void;
  user: UserProfile;
}

const TeamBuilder: React.FC<TeamBuilderProps> = ({ onSave, user }) => {
  const navigate = useNavigate();
  const { matchId } = useParams<{ matchId: string }>();
  const match = MOCK_MATCHES.find(m => m.id === matchId);
  const [selectedPlayers, setSelectedPlayers] = useState<Player[]>([]);
  const [activeTab, setActiveTab] = useState<PlayerRole>(PlayerRole.WK);
  const [step, setStep] = useState<'SELECT' | 'CAPTAIN'>('SELECT');
  const [captainId, setCaptainId] = useState<string | null>(null);
  const [viceCaptainId, setViceCaptainId] = useState<string | null>(null);
  const [filterXI, setFilterXI] = useState(false);

  const team1 = match?.team1 || "Team A";
  const team2 = match?.team2 || "Team B";

  const stats = useMemo(() => {
    return {
      [PlayerRole.WK]: selectedPlayers.filter(p => p.role === PlayerRole.WK).length,
      [PlayerRole.BAT]: selectedPlayers.filter(p => p.role === PlayerRole.BAT).length,
      [PlayerRole.AR]: selectedPlayers.filter(p => p.role === PlayerRole.AR).length,
      [PlayerRole.BOWL]: selectedPlayers.filter(p => p.role === PlayerRole.BOWL).length,
      [team1]: selectedPlayers.filter(p => p.team === team1).length,
      [team2]: selectedPlayers.filter(p => p.team === team2).length,
      totalCredits: selectedPlayers.reduce((sum, p) => sum + p.credits, 0)
    };
  }, [selectedPlayers, team1, team2]);

  const togglePlayer = (player: Player) => {
    const isSelected = selectedPlayers.find(p => p.id === player.id);
    if (isSelected) {
      setSelectedPlayers(selectedPlayers.filter(p => p.id !== player.id));
    } else {
      if (selectedPlayers.length >= 11) return;
      if (stats.totalCredits + player.credits > 100) return;
      setSelectedPlayers([...selectedPlayers, player]);
    }
  };

  const validation = useMemo(() => {
    return ComplianceEngine.validateTeam(selectedPlayers);
  }, [selectedPlayers]);

  const handleNext = () => {
    if (validation.isValid) {
      setStep('CAPTAIN');
    } else {
      alert(validation.error || "Team invalid");
    }
  };

  const handleSaveFinal = () => {
    if (!captainId || !viceCaptainId || !match) return;
    
    const locks = LockService.getLockStatus(match);
    if (!locks.canEditTeam) {
      alert("Selection is now locked as match is live/starting.");
      return;
    }

    const newTeam: UserTeam = {
      id: Math.random().toString(36).substr(2, 9),
      userId: user.id,
      matchId: matchId!,
      playerIds: selectedPlayers.map(p => p.id),
      captainId,
      viceCaptainId,
      totalPoints: 0,
      isDraft: false,
      auditTrail: [{ action: "TEAM_CREATED", timestamp: new Date().toISOString() }]
    };
    onSave(newTeam);
    navigate(`/match/${matchId}`);
  };

  const playersToDisplay = MOCK_PLAYERS
    .filter(p => p.role === activeTab)
    .filter(p => !filterXI || p.isPlayingXI);

  if (step === 'CAPTAIN') {
    return (
      <div className="flex flex-col min-h-screen bg-gray-50 pb-40 animate-in slide-in-from-right-10 duration-500">
        <div className="bg-gray-950 text-white p-8 rounded-b-[3rem] shadow-2xl sticky top-0 z-50">
           <h2 className="text-2xl font-black tracking-tighter mb-2">Select C & VC</h2>
           <p className="text-[10px] text-gray-400 font-black uppercase tracking-[0.2em]">Captain gets 2x Points • Vice Captain gets 1.5x</p>
        </div>

        <div className="p-4 space-y-3">
          {selectedPlayers.map(player => (
            <div key={player.id} className="bg-white p-4 rounded-3xl border border-gray-100 flex items-center justify-between shadow-sm">
               <div className="flex items-center space-x-4">
                  <img src={player.imageUrl} className="w-12 h-12 rounded-2xl bg-gray-100" />
                  <div>
                     <p className="font-black text-gray-900 text-sm leading-none mb-1">{player.name}</p>
                     <p className="text-[9px] text-gray-400 font-bold uppercase">{player.team} • {player.role}</p>
                  </div>
               </div>
               <div className="flex space-x-2">
                  <button 
                    onClick={() => {
                      if (viceCaptainId === player.id) setViceCaptainId(null);
                      setCaptainId(player.id);
                    }}
                    className={`w-12 h-12 rounded-2xl border-2 font-black transition-all ${captainId === player.id ? 'bg-red-600 text-white border-red-600 shadow-lg' : 'bg-white text-gray-400 border-gray-100 hover:border-red-600'}`}
                  >
                    C
                  </button>
                  <button 
                    onClick={() => {
                      if (captainId === player.id) setCaptainId(null);
                      setViceCaptainId(player.id);
                    }}
                    className={`w-12 h-12 rounded-2xl border-2 font-black transition-all ${viceCaptainId === player.id ? 'bg-gray-950 text-white border-black shadow-lg' : 'bg-white text-gray-400 border-gray-100 hover:border-black'}`}
                  >
                    VC
                  </button>
               </div>
            </div>
          ))}
        </div>

        <div className="fixed bottom-0 left-0 right-0 p-6 bg-white border-t flex space-x-4 max-w-2xl mx-auto shadow-[0_-10px_40px_rgba(0,0,0,0.1)]">
           <button onClick={() => setStep('SELECT')} className="flex-1 py-5 border-2 border-gray-900 text-gray-900 rounded-2xl font-black text-xs uppercase tracking-widest active:scale-95 transition-all">Back</button>
           <button 
            onClick={handleSaveFinal} 
            disabled={!captainId || !viceCaptainId}
            className="flex-[2] py-5 bg-red-600 disabled:bg-gray-100 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl active:scale-95 transition-all"
           >
            Save Team
           </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 pb-40">
      {/* HUD Header */}
      <div className="bg-gray-950 text-white p-8 rounded-b-[3rem] sticky top-0 z-50 shadow-2xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <p className="text-[8px] text-gray-500 font-black uppercase tracking-[0.2em] mb-1">Players Selected</p>
            <p className="text-4xl font-black tracking-tighter">{selectedPlayers.length}<span className="text-gray-700 text-xl">/11</span></p>
          </div>
          <div className="text-right">
             <p className="text-[8px] text-gray-500 font-black uppercase tracking-[0.2em] mb-1">Credits Left</p>
             <p className={`text-4xl font-black tracking-tighter ${(100 - stats.totalCredits) < 5 ? 'text-red-500' : 'text-green-400'}`}>
                {(100 - stats.totalCredits).toFixed(1)}
             </p>
          </div>
        </div>

        <div className="flex space-x-2 mb-4">
           <div className="flex-1 bg-white/5 border border-white/10 p-3 rounded-2xl">
              <p className="text-[8px] text-gray-500 font-black uppercase mb-1">{team1}</p>
              <p className="text-xl font-black">{stats[team1]}</p>
           </div>
           <div className="flex-1 bg-white/5 border border-white/10 p-3 rounded-2xl text-right">
              <p className="text-[8px] text-gray-500 font-black uppercase mb-1">{team2}</p>
              <p className="text-xl font-black">{stats[team2]}</p>
           </div>
        </div>

        <div className="flex bg-white/5 rounded-2xl p-1.5 border border-white/10">
          {Object.values(PlayerRole).map(role => (
            <button key={role} onClick={() => setActiveTab(role)} className={`flex-1 py-2 text-[9px] font-black rounded-xl uppercase tracking-widest transition-all ${activeTab === role ? 'bg-red-600 text-white shadow-lg' : 'text-gray-400 hover:text-white'}`}>
              {role} ({stats[role]})
            </button>
          ))}
        </div>
      </div>

      {/* Constraints Indicator */}
      <div className="px-4 py-4">
        {!validation.isValid && selectedPlayers.length > 0 && (
           <div className="bg-orange-50 border border-orange-100 p-4 rounded-2xl flex items-center space-x-3">
              <i className="fas fa-info-circle text-orange-500"></i>
              <p className="text-[9px] text-orange-700 font-black uppercase tracking-tight">{validation.error}</p>
           </div>
        )}
      </div>

      {/* Player List */}
      <div className="px-4 space-y-3">
        {playersToDisplay.map(player => {
          const isSelected = selectedPlayers.some(p => p.id === player.id);
          return (
            <div 
              key={player.id} 
              onClick={() => togglePlayer(player)}
              className={`p-5 rounded-3xl border-2 transition-all cursor-pointer flex justify-between items-center group ${isSelected ? 'bg-red-50 border-red-600 shadow-md' : 'bg-white border-gray-100 hover:border-gray-300'}`}
            >
              <div className="flex items-center space-x-4">
                <div className="relative">
                   <img src={player.imageUrl} className="w-14 h-14 rounded-2xl bg-gray-100 border-2 border-white shadow-sm" />
                   {player.isPlayingXI && (
                     <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 text-white rounded-full flex items-center justify-center border-2 border-white">
                        <i className="fas fa-check text-[8px]"></i>
                     </div>
                   )}
                </div>
                <div>
                   <p className="font-black text-gray-900 text-sm tracking-tight leading-none mb-1">{player.name}</p>
                   <p className="text-[9px] text-gray-400 font-bold uppercase">{player.team} • {player.selectedBy}% Sel</p>
                </div>
              </div>
              <div className="flex items-center space-x-6">
                 <div className="text-right">
                    <p className="text-sm font-black text-gray-900">{player.credits}</p>
                    <p className="text-[7px] text-gray-400 font-black uppercase">Credits</p>
                 </div>
                 <div className={`w-10 h-10 rounded-xl flex items-center justify-center border-2 transition-all ${isSelected ? 'bg-red-600 border-red-600 text-white rotate-90' : 'border-gray-100 text-gray-300'}`}>
                    <i className={`fas ${isSelected ? 'fa-minus' : 'fa-plus'} text-[10px]`}></i>
                 </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer CTA */}
      <div className="fixed bottom-0 left-0 right-0 p-6 bg-white border-t z-50 max-w-2xl mx-auto shadow-[0_-10px_40px_rgba(0,0,0,0.1)]">
         <button 
           onClick={handleNext}
           disabled={selectedPlayers.length !== 11}
           className={`w-full py-5 rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-xl transition-all active:scale-95 flex items-center justify-center ${
            selectedPlayers.length === 11 ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-300'
           }`}
         >
           {selectedPlayers.length === 11 ? 'Choose Captain & VC' : `${11 - selectedPlayers.length} Players Remaining`}
           {selectedPlayers.length === 11 && <i className="fas fa-arrow-right ml-3"></i>}
         </button>
      </div>
    </div>
  );
};

export default TeamBuilder;
