
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Match } from '../types';

interface MatchListProps {
  matches: Match[];
}

const MatchList: React.FC<MatchListProps> = ({ matches }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('ALL');

  const formatIST = (isoString: string) => {
    try {
      return new Date(isoString).toLocaleTimeString('en-IN', {
        timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: true
      }).toUpperCase();
    } catch {
      return "--:--";
    }
  };

  const filtered = matches.filter(m => {
    const matchName = `${m.team1} ${m.team2} ${m.series}`.toLowerCase();
    const searchMatch = matchName.includes(searchQuery.toLowerCase());
    const filterMatch = filterType === 'ALL' || m.status === filterType;
    return searchMatch && filterMatch;
  });

  return (
    <div className="space-y-6">
      <div className="px-2">
        <h2 className="text-2xl font-black text-gray-900 tracking-tighter">Live & Upcoming</h2>
        <div className="mt-4 flex flex-col space-y-4">
          <div className="relative group">
            <i className="fas fa-search absolute left-5 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-red-600 transition-colors"></i>
            <input 
              type="text" 
              placeholder="Search Match or Series..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-14 pr-6 py-4 bg-white border border-gray-100 rounded-2xl font-bold text-sm outline-none focus:ring-2 focus:ring-red-600/20 transition-all shadow-sm"
            />
          </div>
          <div className="flex space-x-2 overflow-x-auto no-scrollbar pb-1">
            {['ALL', 'LIVE', 'UPCOMING', 'COMPLETED'].map(f => (
              <button 
                key={f}
                onClick={() => setFilterType(f)}
                className={`px-6 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest whitespace-nowrap transition-all ${filterType === f ? 'bg-gray-950 text-white shadow-md' : 'bg-white text-gray-400'}`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {filtered.map((match) => {
          const isAbandoned = match.status === 'ABANDONED';
          const isLive = match.status === 'LIVE';
          const istTime = formatIST(match.startTime);
          
          return (
            <Link 
              key={match.id} 
              to={`/match/${match.id}`}
              className={`block bg-white rounded-[2.5rem] shadow-sm border border-gray-100 overflow-hidden hover:shadow-xl transition-all ${isAbandoned ? 'opacity-60 grayscale' : ''}`}
            >
              <div className="px-6 py-3 bg-gray-50/50 border-b flex justify-between items-center">
                <span className="text-[9px] uppercase font-black text-gray-400 tracking-widest truncate max-w-[200px]">
                  {match.series}
                </span>
                <div className="flex items-center space-x-2">
                  {isLive && (
                    <span className="flex items-center bg-red-600 text-white text-[7px] font-black px-2 py-0.5 rounded-full uppercase tracking-tighter">
                      <span className="w-1.5 h-1.5 bg-white rounded-full mr-1 animate-pulse"></span>
                      Live
                    </span>
                  )}
                  {match.tossReleased && <span className="bg-green-600 text-white text-[7px] font-black px-2 py-0.5 rounded-full uppercase">Lineups Out</span>}
                </div>
              </div>
              
              <div className="p-8 flex justify-between items-center">
                <div className="text-center w-1/3">
                  <span className="text-5xl block mb-4">{match.team1Logo || '🏏'}</span>
                  <span className="font-black text-xs text-gray-900 uppercase truncate block">{match.team1}</span>
                </div>
                
                <div className="flex flex-col items-center">
                  {isLive ? (
                     <div className="text-center">
                        <p className="text-[7px] font-black text-red-600 uppercase tracking-widest mb-1">Live Score</p>
                        <p className="text-xs font-black text-gray-900 bg-gray-50 px-3 py-1 rounded-lg border border-gray-100">
                          {match.score || 'In Progress...'}
                        </p>
                     </div>
                  ) : (
                    <>
                      <span className="text-[8px] font-black text-gray-300 uppercase tracking-widest mb-2">Starts At</span>
                      <div className="bg-red-50 text-red-600 px-4 py-2 rounded-xl font-mono font-black text-[10px]">
                        {istTime}
                      </div>
                    </>
                  )}
                </div>
                
                <div className="text-center w-1/3">
                  <span className="text-5xl block mb-4">{match.team2Logo || '🏏'}</span>
                  <span className="font-black text-xs text-gray-900 uppercase truncate block">{match.team2}</span>
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-20 bg-white rounded-[2.5rem] border border-dashed border-gray-200">
           <i className="fas fa-ghost text-4xl text-gray-100 mb-4"></i>
           <p className="text-sm font-black text-gray-300 uppercase tracking-widest">No Matches Found</p>
        </div>
      )}
    </div>
  );
};

export default MatchList;
