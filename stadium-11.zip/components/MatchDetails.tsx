
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Match, Contest, UserProfile, UserTeam, JoinedContest, MatchLockStatus, Player, PlayerRole } from '../types';
import { MOCK_CONTESTS, MOCK_PLAYERS } from '../data/mockData';
import { ContestService } from '../services/contest.service';
import { LockService } from '../services/lock.service';
import { PrizeEngine } from '../services/prize.service';
import { SportsDataService } from '../services/sports.service';
import PrizeBreakupModal from './PrizeBreakupModal';

interface MatchDetailsProps {
  matches: Match[];
  user: UserProfile;
  userTeams: UserTeam[];
  joinedContests: JoinedContest[];
  onJoin: (contest: Contest, team: UserTeam) => Promise<boolean>;
  onClone: (team: UserTeam) => void;
}

const MatchDetails: React.FC<MatchDetailsProps> = ({ matches, user, userTeams, joinedContests, onJoin, onClone }) => {
  const { matchId } = useParams<{ matchId: string }>();
  const navigate = useNavigate();
  const match = matches.find(m => String(m.id) === String(matchId));
  
  const [squad, setSquad] = useState<Player[]>([]);
  const [loadingSquad, setLoadingSquad] = useState(true);
  const [contests, setContests] = useState<Contest[]>(
    MOCK_CONTESTS.filter(c => c.matchId === matchId || c.matchId === 'm1')
  );

  const [timeLeft, setTimeLeft] = useState<string>('--:--:--');
  const [lockStatus, setLockStatus] = useState<MatchLockStatus>({ canJoinContest: true, canEditTeam: true, canChangeCaptain: true });
  const [activeTab, setActiveTab] = useState<'CONTESTS' | 'JOINED' | 'TEAMS' | 'SQUADS'>('CONTESTS');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedContest, setSelectedContest] = useState<Contest | null>(null);
  const [showPrizeBreakup, setShowPrizeBreakup] = useState<Contest | null>(null);

  const isRestrictedState = user.kycDetails && ['Assam', 'Odisha', 'Telangana', 'Andhra Pradesh', 'Sikkim', 'Nagaland'].includes(user.kycDetails.state);

  useEffect(() => {
    if (!match) return;

    // Fetch players if not loaded
    const fetchSquad = async () => {
      setLoadingSquad(true);
      const data = await SportsDataService.getSquadForMatch(match);
      setSquad(data);
      setLoadingSquad(false);
    };
    fetchSquad();

    const timer = setInterval(() => {
      const difference = new Date(match.startTime).getTime() - Date.now();
      const status = LockService.getLockStatus(match);
      setLockStatus(status);

      if (difference <= 0) setTimeLeft('MATCH LIVE');
      else {
        const h = Math.floor(difference / 3600000);
        const m = Math.floor((difference % 3600000) / 60000);
        const s = Math.floor((difference % 60000) / 1000);
        setTimeLeft(`${h}h ${m}m ${s}s`);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [match]);

  if (!match) return (
    <div className="p-10 text-center bg-white rounded-[3rem] border border-gray-100 shadow-sm animate-in fade-in">
       <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6 text-3xl">🔍</div>
       <h2 className="text-2xl font-black text-gray-900 tracking-tighter">Match Data Unavailable</h2>
       <p className="text-sm text-gray-400 font-bold mt-4 leading-relaxed max-w-xs mx-auto">
         The selected match ID <span className="text-red-600">#{matchId}</span> could not be found.
       </p>
       <Link to="/" className="mt-10 inline-block px-8 py-4 bg-red-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl">Return Home</Link>
    </div>
  );

  const handleJoinClick = (contest: Contest) => {
    if (isRestrictedState && contest.entryFee > 0) {
      alert("Paid contests are not allowed in your state. Try our free contests!");
      return;
    }
    if (!user.ageVerified) {
      alert("You must be 18+ to play paid contests.");
      return;
    }
    if (!lockStatus.canJoinContest) {
      alert(lockStatus.lockMessage || "Joining is locked.");
      return;
    }
    if (userTeams.length === 0) {
      navigate(`/match/${matchId}/create-team`);
      return;
    }
    setSelectedContest(contest);
  };

  const filteredContests = contests.filter(c => selectedCategory === 'ALL' || c.category === selectedCategory);
  const myMatchTeams = userTeams.filter(t => t.matchId === matchId);
  const myJoinedContests = joinedContests.filter(jc => jc.contestId && jc.matchId === matchId);
  const isLive = match.status === 'LIVE';

  return (
    <div className="space-y-6">
      {showPrizeBreakup && (
        <PrizeBreakupModal contest={showPrizeBreakup} onClose={() => setShowPrizeBreakup(null)} />
      )}

      {/* Dynamic Header */}
      <div className="bg-red-700 p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden text-white">
        <div className="flex justify-between items-center">
          <div className="text-center w-1/3">
            <span className="text-5xl block mb-2">{match.team1Logo || '🏏'}</span>
            <span className="font-black text-xs uppercase tracking-widest truncate block">{match.team1}</span>
          </div>
          <div className="text-center w-1/3">
             <p className="text-[10px] font-black opacity-60 uppercase mb-1">{isLive ? 'Score' : 'Starts In'}</p>
             <p className={`text-xl font-mono font-black bg-black/20 px-4 py-2 rounded-2xl inline-block border border-white/10 ${isLive ? 'animate-pulse text-yellow-400' : ''}`}>
               {isLive ? (match.score || 'LIVE') : timeLeft}
             </p>
          </div>
          <div className="text-center w-1/3">
            <span className="text-5xl block mb-2">{match.team2Logo || '🏏'}</span>
            <span className="font-black text-xs uppercase tracking-widest truncate block">{match.team2}</span>
          </div>
        </div>
      </div>

      {isRestrictedState && (
        <div className="bg-orange-50 border border-orange-100 p-4 rounded-2xl flex items-center space-x-3">
           <i className="fas fa-location-dot text-orange-600"></i>
           <p className="text-[9px] font-black text-orange-800 uppercase">Your state restricts real-money gaming. Free contests only.</p>
        </div>
      )}

      {/* Tabs */}
      <div className="flex bg-white rounded-3xl shadow-sm border border-gray-100 p-1.5 sticky top-[64px] z-20 overflow-x-auto no-scrollbar">
        <button onClick={() => setActiveTab('CONTESTS')} className={`flex-1 min-w-[100px] py-4 text-[10px] font-black rounded-2xl transition-all ${activeTab === 'CONTESTS' ? 'bg-red-600 text-white' : 'text-gray-400'}`}>CONTESTS</button>
        <button onClick={() => setActiveTab('SQUADS')} className={`flex-1 min-w-[100px] py-4 text-[10px] font-black rounded-2xl transition-all ${activeTab === 'SQUADS' ? 'bg-red-600 text-white' : 'text-gray-400'}`}>SQUADS</button>
        <button onClick={() => setActiveTab('JOINED')} className={`flex-1 min-w-[100px] py-4 text-[10px] font-black rounded-2xl transition-all ${activeTab === 'JOINED' ? 'bg-red-600 text-white' : 'text-gray-400'}`}>JOINED</button>
        <button onClick={() => setActiveTab('TEAMS')} className={`flex-1 min-w-[100px] py-4 text-[10px] font-black rounded-2xl transition-all ${activeTab === 'TEAMS' ? 'bg-red-600 text-white' : 'text-gray-400'}`}>TEAMS ({myMatchTeams.length})</button>
      </div>

      <div className="space-y-4 pb-40">
        {activeTab === 'CONTESTS' && (
          <>
            <div className="flex space-x-2 overflow-x-auto no-scrollbar py-2">
              {['ALL', 'MEGA', 'HOT', 'BEGINNER'].map(cat => (
                <button key={cat} onClick={() => setSelectedCategory(cat)} className={`px-6 py-2 rounded-full text-[9px] font-black uppercase tracking-widest transition-all ${selectedCategory === cat ? 'bg-gray-950 text-white' : 'bg-white text-gray-400'}`}>{cat}</button>
              ))}
            </div>
            {filteredContests.map((contest) => {
              const netPool = PrizeEngine.getNetPrizePool(contest);
              const isJoined = myJoinedContests.some(jc => jc.contestId === contest.id);
              return (
                <div key={contest.id} className="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-[10px] text-gray-400 font-black uppercase mb-1">Prize Pool</p>
                      <p className="text-3xl font-black text-gray-900">₹{netPool.toLocaleString()}</p>
                      <button onClick={() => setShowPrizeBreakup(contest)} className="text-[9px] text-blue-600 font-black uppercase mt-2">View Breakup</button>
                    </div>
                    <button onClick={() => handleJoinClick(contest)} className={`px-10 py-4 rounded-2xl font-black text-xs ${isJoined ? 'bg-gray-100 text-green-600' : 'bg-green-600 text-white'}`}>
                      {isJoined ? 'JOINED' : `₹${contest.entryFee}`}
                    </button>
                  </div>
                </div>
              );
            })}
          </>
        )}

        {activeTab === 'SQUADS' && (
          <div className="space-y-6">
            {loadingSquad ? (
              <div className="p-20 text-center"><div className="w-10 h-10 border-4 border-red-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div><p className="text-[10px] font-black text-gray-400 uppercase">Fetching squads...</p></div>
            ) : (
              [match.team1, match.team2].map(teamName => (
                <div key={teamName} className="space-y-3">
                  <h3 className="font-black text-gray-900 uppercase tracking-widest text-xs px-2">{teamName} Squad</h3>
                  {squad.filter(p => p.team === teamName).map(p => (
                    <div key={p.id} className="bg-white p-4 rounded-3xl border border-gray-100 flex justify-between items-center shadow-sm">
                      <div className="flex items-center space-x-4">
                        <img src={p.imageUrl} className="w-10 h-10 rounded-xl bg-gray-100" />
                        <div>
                          <p className="font-black text-gray-900 text-sm">{p.name}</p>
                          <p className="text-[9px] text-gray-400 font-bold uppercase">{p.role}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        {match.tossReleased && (
                          <span className={`text-[8px] font-black px-2 py-1 rounded-full uppercase ${p.isPlayingXI ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                            {p.isPlayingXI ? 'Playing' : 'Not Playing'}
                          </span>
                        )}
                        <p className="text-[10px] font-black text-gray-900 mt-1">{p.credits} Cr</p>
                      </div>
                    </div>
                  ))}
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'TEAMS' && (
          <div className="space-y-4">
            {myMatchTeams.map((team, idx) => (
              <div key={team.id} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex justify-between items-center">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-xl bg-gray-950 flex items-center justify-center text-white font-black">T{idx + 1}</div>
                  <div>
                    <p className="font-black text-gray-900 uppercase text-xs">Team {idx + 1}</p>
                    <p className="text-[10px] text-gray-400 font-bold mt-1">C: {squad.find(p => p.id === team.captainId)?.name || '...'} • VC: {squad.find(p => p.id === team.viceCaptainId)?.name || '...'}</p>
                  </div>
                </div>
                <button onClick={() => navigate(`/match/${matchId}/create-team`)} className="p-3 bg-gray-50 rounded-xl text-gray-400"><i className="fas fa-edit"></i></button>
              </div>
            ))}
            <button onClick={() => navigate(`/match/${matchId}/create-team`)} className="w-full py-8 border-4 border-dashed border-gray-100 rounded-[2.5rem] text-gray-400 font-black uppercase text-xs">+ Create New Team</button>
          </div>
        )}
      </div>

      <div className="fixed bottom-24 left-4 right-4 max-w-2xl mx-auto flex justify-center pointer-events-none">
        <button onClick={() => navigate(`/match/${matchId}/create-team`)} className="pointer-events-auto px-10 py-5 bg-gray-950 text-white rounded-full font-black text-xs uppercase tracking-widest shadow-2xl border border-white/10 flex items-center">
          <i className="fas fa-plus-circle mr-3 text-lg text-yellow-400"></i>
          Create Team
        </button>
      </div>
    </div>
  );
};

export default MatchDetails;
