
import React from 'react';

interface Announcement {
  id: string;
  type: 'INFO' | 'WARNING' | 'EMERGENCY';
  message: string;
}

const AnnouncementBanner: React.FC<{ announcement: Announcement | null }> = ({ announcement }) => {
  if (!announcement) return null;

  const bgStyles = {
    INFO: 'bg-blue-600 text-white',
    WARNING: 'bg-orange-500 text-white',
    EMERGENCY: 'bg-red-700 text-white animate-pulse'
  };

  return (
    <div className={`w-full py-2 px-4 flex items-center justify-center space-x-3 text-[10px] font-black uppercase tracking-widest ${bgStyles[announcement.type]}`}>
      <i className={`fas ${announcement.type === 'EMERGENCY' ? 'fa-exclamation-triangle' : 'fa-info-circle'}`}></i>
      <span>{announcement.message}</span>
    </div>
  );
};

export default AnnouncementBanner;
