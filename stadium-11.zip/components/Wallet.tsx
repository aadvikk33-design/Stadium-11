
import React, { useState } from 'react';
import { Transaction, UserProfile } from '../types';
import { useNavigate } from 'react-router-dom';

interface WalletProps {
  user: UserProfile;
  transactions: Transaction[];
  onUpdate: (amount: number, type: 'CREDIT' | 'DEBIT', desc: string) => void;
}

const Wallet: React.FC<WalletProps> = ({ user }) => {
  const navigate = useNavigate();
  const isKycVerified = user.kycStatus === 'VERIFIED';
  const netPL = user.totalWinnings - user.totalInvested;

  const handleAddCash = () => {
    if (!user.ageVerified) {
      alert("Only users 18+ can add cash to play.");
      return;
    }
    alert("Payment Gateway Triggered...");
  };

  const handleWithdraw = () => {
    if (user.kycStatus !== 'VERIFIED') {
      alert("Please complete KYC verification before making a withdrawal.");
      navigate('/kyc');
      return;
    }
    if (user.winningsBalance < 100) {
      alert("Minimum withdrawal amount is ₹100.");
      return;
    }
    alert("Withdrawal Request Initiated.");
  };

  return (
    <div className="space-y-6 pb-28">
      {/* Portfolio Header */}
      <div className="bg-gray-950 p-8 rounded-[3rem] text-white shadow-2xl relative overflow-hidden">
        <div className="absolute -top-20 -left-20 w-60 h-60 bg-red-600/10 rounded-full blur-3xl"></div>
        <div className="relative z-10">
          <p className="text-[10px] text-gray-500 font-black uppercase tracking-[0.3em] mb-4">Master Ledger</p>
          <div className="flex justify-between items-end mb-10">
            <div>
              <p className="text-5xl font-black tracking-tighter">₹{user.walletBalance.toLocaleString()}</p>
              <p className="text-[9px] text-gray-500 font-bold uppercase mt-1">Playable Credits</p>
            </div>
            <div className={`text-right ${netPL >= 0 ? 'text-green-400' : 'text-red-500'}`}>
              <p className="text-xl font-black">{netPL >= 0 ? '+' : ''}₹{netPL.toLocaleString()}</p>
              <p className="text-[8px] font-black uppercase tracking-widest opacity-60">Net Profit/Loss</p>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white/5 p-5 rounded-3xl border border-white/5">
              <p className="text-[8px] text-gray-500 font-black uppercase mb-2">Unutilized</p>
              <p className="font-black text-sm">₹{user.unutilizedBalance}</p>
            </div>
            <div className="bg-white/5 p-5 rounded-3xl border border-white/5">
              <p className="text-[8px] text-gray-500 font-black uppercase mb-2">Winnings</p>
              <p className="font-black text-sm text-green-400">₹{user.winningsBalance}</p>
            </div>
            <div className="bg-white/5 p-5 rounded-3xl border border-white/5">
              <p className="text-[8px] text-gray-500 font-black uppercase mb-2">Bonus</p>
              <p className="font-black text-sm text-blue-400">₹{user.bonusBalance}</p>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-2 gap-4">
             <button 
              onClick={handleAddCash}
              className="py-4 bg-white text-gray-900 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl active:scale-95 transition-all"
             >
                Add Cash
             </button>
             <button 
              onClick={handleWithdraw}
              className="py-4 bg-gray-800 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl active:scale-95 transition-all border border-white/5"
             >
                Withdraw
             </button>
          </div>
        </div>
      </div>

      {!user.ageVerified && (
         <div className="bg-red-50 p-6 rounded-[2rem] border border-red-100 flex items-center space-x-4">
            <i className="fas fa-ban text-red-600 text-xl"></i>
            <div>
               <h4 className="font-black text-sm text-red-900 uppercase">Age Restricted</h4>
               <p className="text-[9px] text-red-600 font-bold uppercase mt-0.5">Wallet activities are restricted for users under 18.</p>
            </div>
         </div>
      )}

      {/* Psychological Safety: Net Metrics */}
      <div className="bg-white p-8 rounded-[3rem] border border-gray-100 shadow-sm flex justify-around">
         <div className="text-center">
            <p className="text-[8px] text-gray-400 font-black uppercase tracking-widest mb-1">Total Entry Fees</p>
            <p className="font-black text-lg text-gray-900">₹{user.totalInvested.toLocaleString()}</p>
         </div>
         <div className="w-px h-10 bg-gray-100"></div>
         <div className="text-center">
            <p className="text-[8px] text-gray-400 font-black uppercase tracking-widest mb-1">Lifetime Gains</p>
            <p className="font-black text-lg text-green-600">₹{user.totalWinnings.toLocaleString()}</p>
         </div>
      </div>

      {/* Verification Card */}
      <div className="bg-white p-8 rounded-[3rem] border border-gray-100 shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-black text-xl tracking-tight">Identity Hub</h3>
          <span className="bg-blue-100 text-blue-600 text-[8px] px-3 py-1.5 rounded-full font-black uppercase">Official Verification</span>
        </div>
        
        <div className="space-y-4">
          <div className={`p-6 rounded-[2rem] flex items-center justify-between border-2 ${isKycVerified ? 'bg-green-50 border-green-100' : 'bg-red-50 border-red-100'}`}>
            <div className="flex items-center space-x-4">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${isKycVerified ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                <i className={`fas ${isKycVerified ? 'fa-id-card-clip' : 'fa-id-card'}`}></i>
              </div>
              <div>
                <p className="font-black text-sm text-gray-900">KYC Status</p>
                <p className={`text-[9px] font-bold uppercase tracking-widest ${isKycVerified ? 'text-green-600' : 'text-red-600'}`}>
                   {isKycVerified ? 'Verified Account' : user.kycStatus === 'SUBMITTED' ? 'Review Pending' : 'Action Required'}
                </p>
              </div>
            </div>
            {!isKycVerified && (
               <button onClick={() => navigate('/kyc')} className="bg-red-600 text-white px-6 py-2 rounded-xl text-[10px] font-black uppercase shadow-lg">
                  {user.kycStatus === 'SUBMITTED' ? 'Check' : 'Verify'}
               </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Wallet;
