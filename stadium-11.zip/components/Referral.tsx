
import React from 'react';
import { UserProfile } from '../types';

interface ReferralProps {
  user: UserProfile;
}

const Referral: React.FC<ReferralProps> = ({ user }) => {
  const referralCode = user.referralData.code;

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Join Fantasy Pro!',
        text: `Use my code ${referralCode} to get ₹50 Bonus!`,
        url: window.location.origin,
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-indigo-900 to-black p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
           <i className="fas fa-users text-[8rem]"></i>
        </div>
        <div className="relative z-10">
          <h2 className="text-3xl font-black tracking-tighter mb-2">Refer & Earn</h2>
          <p className="text-[10px] text-indigo-300 font-black uppercase tracking-widest mb-8">Get ₹50 for every friend who joins</p>
          
          <div className="bg-white/10 backdrop-blur-md rounded-3xl p-6 border border-white/10 flex justify-between items-center mb-8">
             <div>
               <p className="text-[9px] text-indigo-400 font-black uppercase mb-1">Your Referral Code</p>
               <p className="text-2xl font-black tracking-widest text-yellow-400">{referralCode}</p>
             </div>
             <button onClick={() => {
               navigator.clipboard.writeText(referralCode);
               alert("Code Copied!");
             }} className="bg-white text-indigo-900 px-6 py-3 rounded-2xl font-black text-[10px] uppercase">Copy</button>
          </div>

          <button onClick={handleShare} className="w-full py-5 bg-indigo-600 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-indigo-700 transition-all flex items-center justify-center">
             <i className="fab fa-whatsapp mr-3 text-lg"></i>
             Share with Friends
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
         <div className="bg-white p-6 rounded-3xl border border-gray-100 text-center">
            <p className="text-2xl font-black text-gray-900">{user.referralData.totalReferrals}</p>
            <p className="text-[9px] text-gray-400 font-black uppercase">Friends Joined</p>
         </div>
         <div className="bg-white p-6 rounded-3xl border border-gray-100 text-center">
            <p className="text-2xl font-black text-green-600">₹{user.referralData.bonusEarned}</p>
            <p className="text-[9px] text-gray-400 font-black uppercase">Bonus Earned</p>
         </div>
      </div>
    </div>
  );
};

export default Referral;
