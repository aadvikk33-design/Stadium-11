
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { UserProfile } from '../types';

interface NavbarProps {
  user: UserProfile;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, onLogout }) => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const menuItems = [
    { label: 'My Profile', icon: 'fa-user-circle', path: '/kyc' },
    { label: 'Refer & Earn', icon: 'fa-share-nodes', path: '/referral', badge: 'NEW' },
    { label: 'Help & Support', icon: 'fa-circle-question', path: '/help' },
    { label: 'Responsible Play', icon: 'fa-shield-heart', path: '/safety' },
  ];

  return (
    <>
      <nav className="bg-red-700 text-white shadow-lg sticky top-0 z-50 h-16">
        <div className="container mx-auto px-4 h-full flex items-center justify-between max-w-2xl">
          <div className="flex items-center space-x-3">
            <button 
              onClick={() => setIsDrawerOpen(true)}
              className="w-10 h-10 flex items-center justify-center hover:bg-white/10 rounded-full transition-all"
            >
              <i className="fas fa-bars text-lg"></i>
            </button>
            <Link to="/" className="flex items-center space-x-2">
              <span className="text-2xl font-black tracking-tighter">FANTASY<span className="text-yellow-400">PRO</span></span>
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            <Link to="/wallet" className="bg-red-800 hover:bg-red-900 transition-all px-4 py-2 rounded-2xl flex items-center space-x-2 border border-white/10">
              <i className="fas fa-wallet text-sm text-yellow-400"></i>
              <span className="font-black text-sm tracking-tight">₹{user.walletBalance}</span>
            </Link>
            
            <Link to="/kyc" className="relative group hidden sm:block">
              <div className={`w-10 h-10 rounded-full border-2 flex items-center justify-center transition-all ${user.kycStatus === 'VERIFIED' ? 'border-green-400 bg-green-950' : 'border-white/20 bg-black/20'}`}>
                <i className={`fas ${user.kycStatus === 'VERIFIED' ? 'fa-check text-green-400' : 'fa-user text-white/50'} text-xs`}></i>
              </div>
            </Link>
          </div>
        </div>
      </nav>

      {/* Side Drawer Overlay */}
      {isDrawerOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] animate-in fade-in"
          onClick={() => setIsDrawerOpen(false)}
        />
      )}

      {/* Side Drawer Content */}
      <div className={`fixed top-0 left-0 h-full w-80 bg-white z-[110] shadow-2xl transform transition-transform duration-300 ease-out flex flex-col ${isDrawerOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="bg-red-700 p-8 text-white relative">
          <button 
            onClick={() => setIsDrawerOpen(false)}
            className="absolute top-6 right-6 text-white/60 hover:text-white"
          >
            <i className="fas fa-times text-xl"></i>
          </button>
          <div className="flex items-center space-x-4 mb-4">
             <div className="w-16 h-16 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-3xl font-black">
                {user.username.charAt(0).toUpperCase()}
             </div>
             <div>
                <h3 className="font-black text-xl tracking-tight leading-none mb-1">{user.username}</h3>
                <p className="text-[10px] text-red-200 font-black uppercase tracking-widest">PRO LEVEL STRATEGIST</p>
             </div>
          </div>
          <div className="flex items-center space-x-2 bg-black/20 p-2 rounded-xl border border-white/5">
            <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase ${user.kycStatus === 'VERIFIED' ? 'bg-green-500 text-white' : 'bg-yellow-500 text-black'}`}>
              {user.kycStatus === 'VERIFIED' ? 'Verified' : 'KYC Pending'}
            </span>
            <span className="text-[8px] font-black text-red-200 uppercase tracking-tighter">Member since 2025</span>
          </div>
        </div>

        <div className="flex-grow py-6 px-4 space-y-2 overflow-y-auto">
          {menuItems.map((item) => (
            <Link 
              key={item.label}
              to={item.path}
              onClick={() => setIsDrawerOpen(false)}
              className="flex items-center justify-between p-4 rounded-2xl hover:bg-gray-50 transition-all group"
            >
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-gray-50 text-gray-400 group-hover:bg-red-50 group-hover:text-red-600 rounded-xl flex items-center justify-center transition-all">
                   <i className={`fas ${item.icon}`}></i>
                </div>
                <span className="font-black text-sm text-gray-700 group-hover:text-gray-900">{item.label}</span>
              </div>
              {item.badge && (
                <span className="bg-red-600 text-white text-[7px] font-black px-1.5 py-0.5 rounded-md animate-pulse">{item.badge}</span>
              )}
            </Link>
          ))}
          
          <div className="pt-6 mt-6 border-t border-gray-100">
             <p className="px-4 text-[9px] font-black text-gray-400 uppercase tracking-[0.2em] mb-4">Admin Controls</p>
             {user.role === 'ADMIN' && (
               <Link 
                 to="/admin/settlements" 
                 onClick={() => setIsDrawerOpen(false)}
                 className="flex items-center space-x-4 p-4 rounded-2xl hover:bg-red-50 text-red-600 transition-all"
               >
                 <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center">
                    <i className="fas fa-gavel"></i>
                 </div>
                 <span className="font-black text-sm">Payout Control</span>
               </Link>
             )}
          </div>
        </div>

        <div className="p-6 border-t border-gray-100">
           <button 
            onClick={() => { onLogout(); setIsDrawerOpen(false); }}
            className="w-full py-4 flex items-center justify-center space-x-3 text-gray-400 hover:text-red-600 font-black text-xs uppercase tracking-widest transition-all"
           >
              <i className="fas fa-sign-out-alt"></i>
              <span>Logout Session</span>
           </button>
           <p className="text-center mt-4 text-[8px] font-bold text-gray-300 uppercase">v2.5.0-PRO-PRODUCTION</p>
        </div>
      </div>
    </>
  );
};

export default Navbar;
