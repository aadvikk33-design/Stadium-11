
import React, { useState } from 'react';

interface WalkthroughProps {
  onComplete: () => void;
}

const Walkthrough: React.FC<WalkthroughProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);

  const steps = [
    {
      title: "Welcome Champion!",
      text: "Ready to build your dream team? We'll show you the ropes in 30 seconds.",
      icon: "🏏"
    },
    {
      title: "100 Credit Limit",
      text: "Select 11 players while staying within the 100 credit limit. Balance is key!",
      icon: "💳"
    },
    {
      title: "Multiplier Magic",
      text: "Captain gets 2x points, Vice-Captain gets 1.5x. Choose them wisely!",
      icon: "🚀"
    },
    {
      title: "Live Action",
      text: "Track your rank in real-time as the actual match happens. Good luck!",
      icon: "🏆"
    }
  ];

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-black/80 backdrop-blur-md">
      <div className="bg-white w-full max-w-sm rounded-[3rem] p-10 text-center shadow-2xl animate-in zoom-in-95 duration-300">
        <div className="text-6xl mb-6">{steps[step].icon}</div>
        <h2 className="text-2xl font-black text-gray-900 mb-4">{steps[step].title}</h2>
        <p className="text-gray-500 font-bold leading-relaxed mb-10">{steps[step].text}</p>
        
        <div className="flex justify-between items-center">
          <div className="flex space-x-2">
            {steps.map((_, i) => (
              <div key={i} className={`h-1.5 rounded-full transition-all ${i === step ? 'w-6 bg-red-600' : 'w-2 bg-gray-200'}`}></div>
            ))}
          </div>
          <button 
            onClick={() => step < steps.length - 1 ? setStep(step + 1) : onComplete()}
            className="px-8 py-3 bg-red-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg active:scale-95 transition-all"
          >
            {step === steps.length - 1 ? 'Start Playing' : 'Next'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Walkthrough;
