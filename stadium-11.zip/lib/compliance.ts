
import { Player, PlayerRole } from '../types';

/**
 * SKILL-BASED COMPLIANCE ENGINE
 * Ensures team selection reflects user skill and strategic knowledge.
 */
export class ComplianceEngine {
  static validateTeam(players: Player[]): { isValid: boolean; error?: string } {
    if (players.length !== 11) {
      return { isValid: false, error: "Team must contain exactly 11 players" };
    }

    const counts = {
      [PlayerRole.WK]: players.filter(p => p.role === PlayerRole.WK).length,
      [PlayerRole.BAT]: players.filter(p => p.role === PlayerRole.BAT).length,
      [PlayerRole.AR]: players.filter(p => p.role === PlayerRole.AR).length,
      [PlayerRole.BOWL]: players.filter(p => p.role === PlayerRole.BOWL).length,
    };

    // Indian Law Compliance: Must have diversity in roles (Skill)
    if (counts[PlayerRole.WK] < 1 || counts[PlayerRole.WK] > 4) return { isValid: false, error: "Pick 1-4 Wicket Keepers" };
    if (counts[PlayerRole.BAT] < 3 || counts[PlayerRole.BAT] > 6) return { isValid: false, error: "Pick 3-6 Batsmen" };
    if (counts[PlayerRole.AR] < 1 || counts[PlayerRole.AR] > 4) return { isValid: false, error: "Pick 1-4 All-Rounders" };
    if (counts[PlayerRole.BOWL] < 3 || counts[PlayerRole.BOWL] > 6) return { isValid: false, error: "Pick 3-6 Bowlers" };

    // Max 7 players from one team
    const teams = players.reduce((acc, p) => {
      acc[p.team] = (acc[p.team] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    for (const team in teams) {
      if (teams[team] > 7) return { isValid: false, error: `Max 7 players from ${team}` };
    }

    return { isValid: true };
  }
}
