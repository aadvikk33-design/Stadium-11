
import { Match, Player, PlayerRole, Contest, PlayerLifecycle } from '../types';

const getTomorrow = () => {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  d.setHours(19, 30, 0, 0);
  return d.toISOString();
};

const getTodayLate = () => {
  const d = new Date();
  d.setHours(d.getHours() + 3);
  return d.toISOString();
};

const getNow = () => new Date().toISOString();

export const MOCK_MATCHES: Match[] = [
  {
    id: 'm1',
    team1: 'India',
    team1Logo: '🇮🇳',
    team2: 'Australia',
    team2Logo: '🇦🇺',
    startTime: getTodayLate(),
    status: 'UPCOMING',
    series: 'International T20 Series',
    tossReleased: true,
    lockConfig: {
      teamEditSeconds: 60,
      contestJoinSeconds: 0,
      captainSwapSeconds: 0
    }
  },
  {
    id: 'm0',
    team1: 'Pakistan',
    team1Logo: '🇵🇰',
    team2: 'New Zealand',
    team2Logo: '🇳🇿',
    startTime: getNow(),
    status: 'LIVE',
    series: 'International T20 Series',
    tossReleased: true,
    score: 'PAK 145/2 (16.4)',
    lockConfig: {
      teamEditSeconds: 60,
      contestJoinSeconds: 0,
      captainSwapSeconds: 0
    }
  },
  {
    id: 'm2',
    team1: 'England',
    team1Logo: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
    team2: 'South Africa',
    team2Logo: '🇿🇦',
    startTime: getTomorrow(),
    status: 'UPCOMING',
    series: 'World Championship Qualifiers',
    tossReleased: false,
    lockConfig: {
      teamEditSeconds: 300,
      contestJoinSeconds: 60,
      captainSwapSeconds: 0
    }
  }
];

export const MOCK_PLAYERS: Player[] = [
  // --- INDIA (11 Players) ---
  { id: 'p1', name: 'R. Sharma', team: 'India', role: PlayerRole.BAT, credits: 10.5, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rohit', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 78, recentForm: 'HOT' },
  { id: 'p2', name: 'V. Kohli', team: 'India', role: PlayerRole.BAT, credits: 11.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Virat', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 92, recentForm: 'HOT' },
  { id: 'p3', name: 'S. Gill', team: 'India', role: PlayerRole.BAT, credits: 9.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Gill', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 45, recentForm: 'AVERAGE' },
  { id: 'p4', name: 'R. Pant', team: 'India', role: PlayerRole.WK, credits: 9.5, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Pant', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 65, recentForm: 'HOT' },
  { id: 'p5', name: 'KL Rahul', team: 'India', role: PlayerRole.WK, credits: 9.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Rahul', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 30, recentForm: 'AVERAGE' },
  { id: 'p6', name: 'H. Pandya', team: 'India', role: PlayerRole.AR, credits: 10.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Hardik', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 85, recentForm: 'HOT' },
  { id: 'p7', name: 'R. Jadeja', team: 'India', role: PlayerRole.AR, credits: 9.5, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jadeja', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 70, recentForm: 'AVERAGE' },
  { id: 'p8', name: 'J. Bumrah', team: 'India', role: PlayerRole.BOWL, credits: 11.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Bumrah', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 88, recentForm: 'HOT' },
  { id: 'p9', name: 'M. Siraj', team: 'India', role: PlayerRole.BOWL, credits: 8.5, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Siraj', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 40, recentForm: 'AVERAGE' },
  { id: 'p10', name: 'K. Yadav', team: 'India', role: PlayerRole.BOWL, credits: 9.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Kuldeep', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 55, recentForm: 'HOT' },
  { id: 'p11', name: 'A. Singh', team: 'India', role: PlayerRole.BOWL, credits: 8.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Arshdeep', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 25, recentForm: 'AVERAGE' },

  // --- AUSTRALIA (11 Players) ---
  { id: 'p12', name: 'T. Head', team: 'Australia', role: PlayerRole.BAT, credits: 10.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Head', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 72, recentForm: 'HOT' },
  { id: 'p13', name: 'D. Warner', team: 'Australia', role: PlayerRole.BAT, credits: 9.5, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Warner', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 68, recentForm: 'AVERAGE' },
  { id: 'p14', name: 'M. Marsh', team: 'Australia', role: PlayerRole.AR, credits: 9.5, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Marsh', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 50, recentForm: 'HOT' },
  { id: 'p15', name: 'G. Maxwell', team: 'Australia', role: PlayerRole.AR, credits: 10.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Maxwell', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 80, recentForm: 'HOT' },
  { id: 'p16', name: 'M. Stoinis', team: 'Australia', role: PlayerRole.AR, credits: 9.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Stoinis', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 40, recentForm: 'AVERAGE' },
  { id: 'p17', name: 'J. Inglis', team: 'Australia', role: PlayerRole.WK, credits: 8.5, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Inglis', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 25, recentForm: 'AVERAGE' },
  { id: 'p18', name: 'M. Wade', team: 'Australia', role: PlayerRole.WK, credits: 8.5, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Wade', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 15, recentForm: 'AVERAGE' },
  { id: 'p19', name: 'P. Cummins', team: 'Australia', role: PlayerRole.BOWL, credits: 9.5, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Cummins', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 61, recentForm: 'AVERAGE' },
  { id: 'p20', name: 'M. Starc', team: 'Australia', role: PlayerRole.BOWL, credits: 10.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Starc', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 59, recentForm: 'HOT' },
  { id: 'p21', name: 'A. Zampa', team: 'Australia', role: PlayerRole.BOWL, credits: 9.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Zampa', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 45, recentForm: 'COLD' },
  { id: 'p22', name: 'J. Hazlewood', team: 'Australia', role: PlayerRole.BOWL, credits: 9.0, points: 0, imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Josh', lifecycle: PlayerLifecycle.CONFIRMED, isPlayingXI: true, selectedBy: 35, recentForm: 'AVERAGE' },
];

export const MOCK_CONTESTS: Contest[] = [
  { 
    id: 'c1', matchId: 'm1', name: 'Mega Contest', prizePool: 1000000, entryFee: 49, 
    totalSpots: 50000, filledSpots: 24500, minSpotsToStart: 1000, type: 'MEGA', 
    isGuaranteed: true, maxTeamsPerUser: 20, category: 'MEGA', rakePercentage: 15, 
    prizeStructureId: 'ps_mega', escrowStatus: 'PENDING', settlementStatus: 'PENDING' 
  },
  { 
    id: 'c2', matchId: 'm1', name: 'Hot Contest', prizePool: 10000, entryFee: 299, 
    totalSpots: 40, filledSpots: 38, minSpotsToStart: 10, type: 'WINNER_TAKES_ALL', 
    isGuaranteed: false, maxTeamsPerUser: 1, category: 'HOT', rakePercentage: 10, 
    prizeStructureId: 'ps_winner_takes_all', escrowStatus: 'PENDING', settlementStatus: 'PENDING' 
  },
  { 
    id: 'c3', matchId: 'm1', name: 'Beginner Cup', prizePool: 500, entryFee: 10, 
    totalSpots: 100, filledSpots: 20, minSpotsToStart: 2, type: 'MEGA', 
    isGuaranteed: true, maxTeamsPerUser: 1, category: 'BEGINNER', rakePercentage: 5, 
    prizeStructureId: 'ps_top_3', escrowStatus: 'PENDING', settlementStatus: 'PENDING' 
  },
];
