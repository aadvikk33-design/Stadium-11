
export enum PlayerRole {
  WK = 'WK',
  BAT = 'BAT',
  AR = 'AR',
  BOWL = 'BOWL'
}

export type TransactionType = 'CREDIT' | 'DEBIT' | 'REFUND' | 'WINNINGS' | 'TDS_DEDUCTION';

export enum PlayerLifecycle {
  PROBABLE = 'PROBABLE',
  CONFIRMED = 'CONFIRMED',
  IMPACT = 'IMPACT',
  SUBSTITUTE = 'SUBSTITUTE',
  RULED_OUT = 'RULED_OUT'
}

export interface Player {
  id: string;
  name: string;
  team: string;
  role: PlayerRole;
  credits: number;
  points: number; // Current live fantasy points
  imageUrl: string;
  lifecycle: PlayerLifecycle;
  isPlayingXI: boolean;
  isImpactPlayer?: boolean;
  selectedBy?: number;
  recentForm?: 'HOT' | 'COLD' | 'AVERAGE';
  pointBreakdown?: { event: string; count: number; pts: number }[];
}

export interface MatchLockStatus {
  canJoinContest: boolean;
  canEditTeam: boolean;
  canChangeCaptain: boolean;
  lockMessage?: string;
}

export interface Match {
  id: string;
  team1: string;
  team1Logo: string;
  team2: string;
  team2Logo: string;
  startTime: string; 
  status: 'UPCOMING' | 'LIVE' | 'COMPLETED' | 'CANCELLED' | 'ABANDONED' | 'DELAYED';
  series: string;
  venue?: string;
  score?: string;
  isRainDelay?: boolean;
  isDLSApplied?: boolean;
  tossReleased: boolean;
  lockConfig: {
    teamEditSeconds: number;
    contestJoinSeconds: number;
    captainSwapSeconds: number;
  };
}

export interface Contest {
  id: string;
  matchId: string;
  name: string;
  prizePool: number;
  entryFee: number;
  totalSpots: number;
  filledSpots: number;
  minSpotsToStart: number;
  type: 'MEGA' | 'HEAD_TO_HEAD' | 'WINNER_TAKES_ALL';
  isGuaranteed: boolean;
  maxTeamsPerUser: number;
  category?: 'HOT' | 'MEGA' | 'BEGINNER';
  rakePercentage: number;
  prizeStructureId: string;
  isCancelled?: boolean;
  cancelReason?: string;
  settlementStatus: 'PENDING' | 'SETTLED' | 'CANCELLED';
  escrowStatus: 'PENDING' | 'RELEASED' | 'REFUNDED';
  inviteCode?: string;
}

export interface PrizeSlab {
  rankStart: number;
  rankEnd: number;
  percentage: number;
}

export interface PrizeStructure {
  id: string;
  name: string;
  slabs: PrizeSlab[];
}

export interface UserTeam {
  id: string;
  userId: string;
  matchId: string;
  playerIds: string[];
  captainId: string;
  viceCaptainId: string;
  totalPoints: number;
  rank?: number;
  isDraft?: boolean;
  auditTrail: { action: string; timestamp: string }[];
}

export interface JoinedContest {
  id: string;
  contestId: string;
  matchId: string;
  teamId: string;
  joinedAt: string;
  refunded?: boolean;
  winnings?: number;
  tdsDeducted?: number;
}

export interface KYCDetails {
  panNumber: string;
  fullName: string;
  dob: string;
  state: string;
  panImage?: string; 
  rejectionReason?: string;
  submittedAt?: string;
  status: 'NOT_STARTED' | 'SUBMITTED' | 'PENDING' | 'VERIFIED' | 'REJECTED' | 'RE_VERIFICATION_REQUIRED';
}

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  phone?: string;
  dob: string; 
  ageVerified: boolean;
  role: 'USER' | 'ADMIN';
  walletBalance: number;
  unutilizedBalance: number;
  winningsBalance: number;
  bonusBalance: number;
  totalInvested: number;
  totalWinnings: number;
  totalTdsPaid: number;
  kycStatus: KYCDetails['status'];
  referralData: { code: string; totalReferrals: number; bonusEarned: number; };
  activeDevices: DeviceMetadata[];
  lossStreakCount: number;
  selfExclusionUntil?: string;
  isAccountFrozen: boolean;
  lastCoolingOffNudge?: string;
  isNewUser?: boolean;
  contestsJoined?: number;
  kycDetails?: KYCDetails;
  consentLogs: { type: string; timestamp: string; version: string }[];
  provider?: 'GOOGLE' | 'FACEBOOK' | 'EMAIL' | 'OTP';
  isEmailVerified?: boolean;
}

export interface DeviceMetadata {
  deviceId: string;
  lastLogin: string;
  ip: string;
}

export interface AuthSession {
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
  user: UserProfile;
}

export interface Transaction {
  id: string;
  amount: number;
  tdsAmount?: number;
  netAmount: number;
  type: TransactionType;
  description: string;
  timestamp: string;
  status: 'PENDING' | 'SUCCESS' | 'FAILED';
  referenceId: string; 
  reason?: string;
  breakdown?: {
    bonusUsed?: number;
    unutilizedUsed?: number;
    winningsUsed?: number;
  };
}

export interface OTPChallenge {
  id: string;
  target: string;
  type: 'EMAIL' | 'PHONE';
  expiry: number;
  retryCount: number;
  cooldownUntil: number;
}

export interface PointSystem {
  version: string;
  rules: {
    RUN: number;
    WICKET: number;
    CATCH: number;
    BOUNDARY_BONUS: number;
    SIX_BONUS: number;
    MAIDEN_OVER: number;
    STUMPING: number;
    CAPTAIN_MULT: number;
    VC_MULT: number;
  };
}
